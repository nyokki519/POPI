# 冒頭抜粋・試聴版 — 全曲伴奏は未完成

## 収録範囲
添付PDF 8ページ冒頭のアウフタクト（16分音符）＋続く3小節だけ。
冒頭のGの4オクターブ、続く2小節のタイで結ばれたGのオクターブ、その次のピアノ伴奏を入力した。
次の小節以降、Allegretto、Boléro、Presto、カデンツァは収録していない。
これは部分成果であり、通し練習や本番用の完成伴奏ではない。

## ファイル
A_opening_excerpt_ONLY: Andante 付点四分音符=50。音符部分7.4秒＋音の減衰用3秒。
B_opening_excerpt_ONLY: Andante 付点四分音符=40（Aの80%）。音符部分9.25秒＋音の減衰用3秒。
C_opening_excerpt_ONLY: Andante 付点四分音符=50の一定テンポ。この短い抜粋ではAと同じ演奏データ。
各版のWAV（44.1kHz、24bit PCM、ステレオ）、MP3（320kbps）、編集可能なMIDI Type 1、MusicXMLを同梱。
ファイル名のA/B/Cは、この抜粋のバージョンを表し、全曲の3版が完成したという意味ではない。

## 入力と表現
ピアノの実音を使用。サックスパートを演奏データに含めていない。
音符・休符・タイはこの抜粋について原譜画像と目視照合した。
左右の手を別トラック・別譜表にした。双方ともピアノ音色。
強弱の基準をff、ppとし、繰り返す和音のベロシティをわずかに調整。
音符の開始位置はずらしていない。第3小節の8分音符は分離のため音価の92%で離鍵し、拍と小節の長さは維持。
原譜のクレッシェンド等の表現の完全再現は未達。Aは全曲の「原譜準拠完成版」ではない。
アウフタクトを含む全長は9.25四分音符分。MIDIの発音開始イベントは27。

## ピアノ音源
Salamander Grand Piano SF2 V3+20200602。
原音源: Yamaha C5 / Alexander Holm。SF2化: Roberto / FreePats。
出典: https://freepats.zenvoid.org/Piano/acoustic-grand-piano.html
ライセンス: Creative Commons Attribution 3.0。
PIANO-SAMPLE-LICENSE.txtに配布元の説明とクレジットを同梱。
SF2版は元のSFZ版のペダル・ハンマー・弦共鳴ノイズ等を一部省略した版。
FluidSynthでレンダリング。追加リバーブ・コーラス・クリック・他楽器はなし。

## 検証
3版とも27発音、2ピアノ譜表、MIDIプログラム0のみ。
MusicXMLとMIDIで音高の集合と音数が一致。譜面の範囲は0〜3小節。
WAVのサンプルレート、PCM_24、ステレオ、有限値、クリッピングなしを確認。
MP3の320kbps、44.1kHzをFFprobeで確認し、FFmpegで全体のデコード成功を確認。
音声の聴取による最終確認、第三者による校合、全曲検証は未実施。
audio-checks.jsonと各版のnote_events.jsonは数値検証と音符入力内容。
これらの検査は全曲の原譜忠実性を保証するものではない。

## 既存資料の探索
通信設定反映後、IMSLP・MuseScore・Web検索を調査。
- https://imslp.org/wiki/Andante_et_Bol%C3%A9ro_(Demersseman,_Jules)
  IJD 30、テナーとピアノ、A.S.164、1866。添付と同じ画像譜が1件。
  掲載ページではMIDI・伴奏録音・Source Filesはいずれも0件。
- https://musescore.com/user/97106398/scores/16353259
  同曲・テナーとピアノの出版社公式楽譜の候補。ページタイトルのみ確認。
  編集可能データの正規取得と原譜一致は未確認で、今回の音源には使用していない。
- https://www.sheetmusicplus.com/en/product/jules-demersseman-premier-solo-andante-et-bolero-for-tenor-saxophone-and-piano-20075919.html
  検索結果でMusik Fabrikの販売譜を確認。購入・利用はしていない。

全曲に使用できる無料の校合済みMIDI/MusicXMLは今回の探索では見つからなかった。
アルト用のPremier Solo（IJD 29、A.S.163）は別の曲なので不採用。

## 自動認識
Audiveris 5.11.0で6ページ認識を試行、OCR言語データを補って冒頭を再試行、5.10.0でも6ページを試行。
冒頭で符尾・符幹の結合処理が失敗し、他ページにも音部記号、調号、拍子、パート・段構成の認識不良がある。
全曲の正しいMusicXMLにはできなかった。未校合の自動認識結果を伴奏として出力していない。

## 未完成の範囲
第4小節以降の全曲の入力・校合、全曲の表現・テンポ変化、待ち時間決定とタイミング表、全曲3版のレンダリング。
承認済み基本テンポはAndante=付点四分音符50、Allegretto=四分音符100、Boléro=四分音符120、Presto=四分音符160。
Bはそれぞれ80%、Cは各区間で一定。待ち時間は制作者が設定し秒数を明記する方針は承認済みだが、この抜粋には該当区間がない。
