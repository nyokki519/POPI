"""Source inventory and rejection audit. Never renders unverified OMR results."""
from pathlib import Path
from fractions import Fraction
import csv
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = next(Path('/workspace/attachments').glob('*/*Demersseman.pdf'))
SYSTEM_COUNTS = {8: [6, 5, 4, 2], 9: [4, 3, 3, 1],
                 10: [4, 4, 5, 6], 11: [4, 4, 5, 6],
                 12: [4, 3, 3, 3], 13: [3, 3, 5, 6]}

def xml_in_mxl(path):
    with zipfile.ZipFile(path) as archive:
        container = ET.fromstring(archive.read('META-INF/container.xml'))
        rootfile = next(e.get('full-path') for e in container.iter()
                        if e.tag.endswith('rootfile'))
        return archive.read(rootfile)

def rhythm_ends(measure, divisions):
    cursor = Fraction(0)
    ends = {}
    previous_onset = Fraction(0)
    for element in measure:
        if element.tag in ('backup', 'forward'):
            value = Fraction(element.findtext('duration', '0')) / divisions
            cursor += value if element.tag == 'forward' else -value
        elif element.tag == 'note' and element.find('grace') is None:
            duration = Fraction(element.findtext('duration', '0')) / divisions
            chord = element.find('chord') is not None
            onset = previous_onset if chord else cursor
            voice = element.findtext('voice', '1')
            ends[voice] = max(ends.get(voice, Fraction(0)), onset + duration)
            if not chord:
                previous_onset = onset
                cursor += duration
    return {voice: str(end) for voice, end in ends.items()}

def main():
    out = ROOT / 'audit-delivery'
    out.mkdir(exist_ok=True)
    raw = out / 'UNVERIFIED_OMR_DO_NOT_RENDER'
    raw.mkdir(exist_ok=True)
    spans = []
    number = 0
    for page, counts in SYSTEM_COUNTS.items():
        for system, count in enumerate(counts, 1):
            for position in range(1, count + 1):
                special = 'pickup' if number == 0 else 'free_cadenza' if number == 27 else ''
                section = 'Andante' if number < 32 else 'Allegretto' if number < 40 else 'Bolero' if number < 84 else 'Presto'
                spans.append(dict(span_id=number, pdf_page=page,
                    printed_page=page-6, system=system, position=position,
                    section=section, meter='free' if special == 'free_cadenza' else '6/8' if number < 32 else '3/4',
                    special=special, source_span_located=True,
                    RH_all_notes_verified=False, LH_all_notes_verified=False,
                    voice_durations_verified=False, accidentals_verified=False,
                    harmony_verified=False, XML_MIDI_match_verified=False,
                    status='NOT_VERIFIED_NOT_READY_FOR_RENDER'))
                number += 1
    assert number == 96 and spans[-1]['pdf_page'] == 13
    with (out / 'measure-verification-NOT-COMPLETE.csv').open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=spans[0].keys())
        writer.writeheader(); writer.writerows(spans)

    summaries = []
    omr_measures = []
    for page in SYSTEM_COUNTS:
        mxl = ROOT / 'piano-omr-output' / f'piano-pdf-{page:02}.mxl'
        data = xml_in_mxl(mxl)
        (raw / f'UNVERIFIED-pdf-{page:02}.musicxml').write_bytes(data)
        root = ET.fromstring(data)
        measures = root.findall('part/measure')
        divisions = 1
        for measure in measures:
            if measure.findtext('attributes/divisions'):
                divisions = int(measure.findtext('attributes/divisions'))
            omr_measures.append(dict(pdf_page=page,
                omr_local_measure=measure.get('number'),
                voice_end_quarters=rhythm_ends(measure, divisions),
                note_elements=len(measure.findall('note')),
                verified_against_source=False))
        summaries.append(dict(pdf_page=page,
            source_notated_spans=sum(SYSTEM_COUNTS[page]),
            exported_measure_elements=len(measures),
            exported_local_ids=[m.get('number') for m in measures],
            note_elements=len(root.findall('part/measure/note')),
            detected_time_signatures=[{'beats':t.findtext('beats'), 'beat_type':t.findtext('beat-type')} for t in root.findall('.//time')],
            detected_fifths=[k.findtext('fifths') for k in root.findall('.//key')],
            detected_clefs=[{'staff':c.get('number'), 'sign':c.findtext('sign'), 'line':c.findtext('line')} for c in root.findall('.//clef')],
            accepted_for_performance=False))
        shutil.copyfile(mxl, raw / f'UNVERIFIED-pdf-{page:02}.mxl')
        shutil.copyfile(ROOT / 'piano-omr-output' / f'piano-pdf-{page:02}.omr', raw / f'UNVERIFIED-pdf-{page:02}.omr')
    (out / 'omr-audit.json').write_text(json.dumps(summaries, indent=2), encoding='utf-8')
    (out / 'omr-voice-endpoints-UNVERIFIED.json').write_text(json.dumps(omr_measures, indent=2), encoding='utf-8')

    import mido
    old_midi = ROOT.parent / 'opening-excerpt' / 'A_opening_excerpt_ONLY.mid'
    mid = mido.MidiFile(old_midi)
    shortened = []
    for track in mid.tracks:
        tick = 0; active = {}
        for msg in track:
            tick += msg.time
            if msg.type == 'note_on' and msg.velocity:
                active[msg.note] = tick
            elif msg.type == 'note_off' or (msg.type == 'note_on' and not msg.velocity):
                onset = active.pop(msg.note)
                if onset >= 6.25 * mid.ticks_per_beat:
                    duration = Fraction(tick-onset, mid.ticks_per_beat)
                    if duration != Fraction(1, 2):
                        shortened.append(dict(pitch=msg.note,
                            onset_quarters=float(Fraction(onset, mid.ticks_per_beat)),
                            actual_duration_quarters=float(duration),
                            written_duration_quarters=0.5))
    (out / 'previous-excerpt-duration-errors.json').write_text(json.dumps(shortened, indent=2), encoding='utf-8')
    assert len(shortened) == 19
    manifest = dict(status='INCOMPLETE_NO_CORRECTED_AUDIO',
        source_complete=True, source_pages=14,
        source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        source_score_pdf_pages=[8, 9, 10, 11, 12, 13],
        notation_span_count=96,
        span_numbering='0 = pickup, 27 = unbarred cadenza; these are source-layout identifiers, not a certified playback measure count',
        complete_note_verification=False, render_allowed=False,
        A_full_audio_created=False, B_slow_full_audio_created=False,
        MIDI_full_created=False, verified_full_MusicXML_created=False,
        previous_excerpt_has_duration_errors=True,
        previous_excerpt_is_not_the_full_work=True)
    (out / 'status.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    shutil.copyfile(SOURCE, out / 'original-IMSLP567628-AS164-14pages.pdf')
    for name in ['prepare_piano_omr.py', 'audit_revision.py', 'piano-omr-08.log', 'piano-omr-rest.log']:
        shutil.copyfile(ROOT / name, out / name)
    shutil.copyfile(ROOT.parent / 'make_excerpt.py', out / 'previous-excerpt-generator-gate-fixed-NOT-FULL.py')
    print(json.dumps({'source_pages':14, 'notation_spans':96,
        'omr_exports':len(summaries), 'previous_duration_errors':len(shortened),
        'render_allowed':False, 'delivery':str(out)}, indent=2))

if __name__ == '__main__':
    main()
