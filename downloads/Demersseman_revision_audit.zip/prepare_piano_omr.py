"""Crop the source piano systems for OMR; never alter musical symbols.

These are recognition inputs, not a verified transcription. Source-page/row
coordinates are preserved here to make every crop auditable.
"""
from pathlib import Path
from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parent
REGIONS = {
    8: [(375, 510), (588, 735), (798, 938), (999, 1143)],
    9: [(260, 408), (505, 640), (735, 880), (970, 1130)],
    10: [(254, 405), (500, 643), (741, 877), (965, 1111)],
    11: [(260, 397), (501, 650), (739, 875), (976, 1120)],
    12: [(257, 395), (498, 632), (739, 874), (977, 1110)],
    13: [(263, 397), (508, 642), (745, 879), (977, 1130)],
}

def main():
    dest = ROOT / "piano-omr-input"
    dest.mkdir(exist_ok=True)
    for page, regions in REGIONS.items():
        original = Image.open(ROOT / "source-images" / f"pdf-{page:02}.png")
        crops = [original.crop((105, top, 930, bottom)) for top, bottom in regions]
        canvas = Image.new("L", (925, sum(c.height for c in crops) + 90 * 5), 255)
        pos = 90
        for crop in crops:
            canvas.paste(ImageOps.autocontrast(crop.convert("L")), (50, pos))
            pos += crop.height + 90
        canvas = canvas.resize((canvas.width * 3, canvas.height * 3), Image.Resampling.LANCZOS)
        canvas.save(dest / f"piano-pdf-{page:02}.png", dpi=(400, 400))
    print(f"Prepared {len(REGIONS)} piano-only recognition inputs; not verified music data.")

if __name__ == "__main__":
    main()
