"""Create a limited opening excerpt; it is not a certified complete transcription."""
from pathlib import Path
import ctypes as C, json, subprocess, shutil, zipfile
import numpy as np
import soundfile as sf
import mido
from music21 import stream, chord, note, meter, key, clef, instrument, tie, metadata, dynamics, tempo

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'opening-excerpt'
OUT.mkdir(exist_ok=True)
FONT=ROOT/'soundfonts/SalamanderGrandPiano-SF2-V3+20200602/SalamanderGrandPiano-V3+20200602.sf2'

def make_score(bpm):
    s=stream.Score()
    s.metadata=metadata.Metadata()
    s.metadata.title='Premier Solo, Andante et Boléro — opening excerpt only'
    s.metadata.composer='Jules Demersseman'
    for staff_id, pitches in [('RH',['G4','G5']),('LH',['G2','G3'])]:
        p=stream.PartStaff(id=staff_id)
        p.insert(0,instrument.Piano())
        p.partName='Piano '+staff_id
        pickup=stream.Measure(number=0)
        pickup.insert(0,clef.TrebleClef() if staff_id=='RH' else clef.BassClef())
        pickup.insert(0,key.KeySignature(-3))
        pickup.insert(0,meter.TimeSignature('6/8'))
        if staff_id=='RH':
            pickup.insert(0,tempo.MetronomeMark(number=bpm,referent=note.Note(type='quarter',dots=1)))
            pickup.insert(0,dynamics.Dynamic('ff'))
        c=chord.Chord(pitches,quarterLength=.25)
        c.volume.velocity=100
        pickup.append(c)
        pickup.padAsAnacrusis()
        p.append(pickup)
        for num in [1,2]:
            m=stream.Measure(number=num)
            c=chord.Chord(pitches,quarterLength=3)
            c.tie=tie.Tie('start' if num==1 else 'stop')
            c.volume.velocity=88
            m.append(c)
            p.append(m)
        m=stream.Measure(number=3)
        if staff_id=='RH':
            m.insert(0,dynamics.Dynamic('pp'))
            for vel in [43,41,40,43,41,40]:
                c=chord.Chord(['G3','C4','E-4'],quarterLength=.5)
                c.volume.velocity=vel
                m.append(c)
        else:
            n=note.Note('C3',quarterLength=.5)
            n.volume.velocity=43
            m.append(n)
            m.append(note.Rest(quarterLength=.5))
            m.append(note.Rest(quarterLength=1))
            m.append(note.Rest(quarterLength=1))
        p.append(m)
        s.insert(0,p)
    return s

def make_midi(path,bpm):
    mid=mido.MidiFile(type=1,ticks_per_beat=960)
    meta=mido.MidiTrack();mid.tracks.append(meta)
    meta.append(mido.MetaMessage('track_name',name='OPENING EXCERPT ONLY - not complete accompaniment',time=0))
    meta.append(mido.MetaMessage('set_tempo',tempo=mido.bpm2tempo(bpm*1.5),time=0))
    meta.append(mido.MetaMessage('time_signature',numerator=6,denominator=8,time=0))
    meta.append(mido.MetaMessage('key_signature',key='Cm',time=0))
    meta.append(mido.MetaMessage('end_of_track',time=8880))
    audit=[]
    for ch,st in enumerate(['RH','LH']):
        tr=mido.MidiTrack();mid.tracks.append(tr)
        tr.append(mido.MetaMessage('track_name',name='Piano '+st,time=0))
        tr.append(mido.Message('program_change',channel=ch,program=0,time=0))
        tr.append(mido.Message('control_change',channel=ch,control=7,value=100,time=0))
        events=[]
        def add(start,duration,ps,velocity,source):
            for pitch in ps:
                events.append((round(start*960),1,mido.Message('note_on',channel=ch,note=pitch,velocity=velocity)))
                events.append((round((start+duration)*960),0,mido.Message('note_off',channel=ch,note=pitch,velocity=0)))
                audit.append(dict(staff=st,source=source,pitch=pitch,start_quarters=start,duration_quarters=duration,velocity=velocity))
        ps=[67,79] if st=='RH' else [43,55]
        add(0,.25,ps,100,'pickup: sixteenth')
        add(.25,6,ps,88,'bars 1–2: tied dotted halves')
        if st=='RH':
            for i,v in enumerate([43,41,40,43,41,40]):add(6.25+i*.5,.5,[55,60,63],v,'bar 3: six eighth-note chords')
        else:add(6.25,.5,[48],43,'bar 3: C3 eighth, followed by rests')
        prev=0
        for tick,_,msg in sorted(events,key=lambda x:(x[0],x[1])):
            msg.time=tick-prev;tr.append(msg);prev=tick
        tr.append(mido.MetaMessage('end_of_track',time=8880-prev))
    mid.save(path)
    return audit

def render(midipath,wavpath):
    f=C.CDLL('libfluidsynth.so.3')
    def func(name,ret,args):
        fn=getattr(f,name);fn.restype=ret;fn.argtypes=args;return fn
    ptr=C.c_void_p;I=C.c_int;S=C.c_char_p
    ns=func('new_fluid_settings',ptr,[])
    sn=func('fluid_settings_setnum',I,[ptr,S,C.c_double])
    si=func('fluid_settings_setint',I,[ptr,S,I])
    settings=ns();sn(settings,b'synth.sample-rate',44100);sn(settings,b'synth.gain',.5)
    si(settings,b'synth.reverb.active',0);si(settings,b'synth.chorus.active',0)
    synth=func('new_fluid_synth',ptr,[ptr])(settings)
    sfid=func('fluid_synth_sfload',I,[ptr,S,I])(synth,str(FONT).encode(),1)
    assert sfid>=0
    select=func('fluid_synth_program_select',I,[ptr,I,I,I,I])
    for ch in [0,1]:assert select(synth,ch,sfid,0,0)==0
    on=func('fluid_synth_noteon',I,[ptr,I,I,I]);off=func('fluid_synth_noteoff',I,[ptr,I,I])
    cc=func('fluid_synth_cc',I,[ptr,I,I,I])
    write=func('fluid_synth_write_float',I,[ptr,I,ptr,I,I,ptr,I,I])
    blocks=[];frame=0;elapsed=0.
    def samples(n):
        if n<=0:return
        l=np.zeros(n,np.float32);r=np.zeros(n,np.float32)
        assert write(synth,n,l.ctypes.data,0,1,r.ctypes.data,0,1)==0
        blocks.append(np.column_stack([l,r]))
    for msg in mido.MidiFile(midipath):
        elapsed+=msg.time
        target=round(elapsed*44100);samples(target-frame);frame=target
        if msg.type=='note_on':on(synth,msg.channel,msg.note,msg.velocity)
        elif msg.type=='note_off':off(synth,msg.channel,msg.note)
        elif msg.type=='control_change':cc(synth,msg.channel,msg.control,msg.value)
    samples(3*44100)
    audio=np.concatenate(blocks)
    peak=float(np.max(np.abs(audio)))
    assert peak>0 and np.isfinite(audio).all()
    if peak>.89:audio*=.89/peak
    sf.write(wavpath,audio,44100,subtype='PCM_24')
    func('delete_fluid_synth',None,[ptr])(synth)
    func('delete_fluid_settings',None,[ptr])(settings)
    return {'frames':len(audio),'seconds':len(audio)/44100,'peak':float(np.max(np.abs(audio))),'rms':float(np.sqrt(np.mean(audio**2)))}

results={}
for label,bpm in [('A',50),('B',40),('C',50)]:
    base=OUT/f'{label}_opening_excerpt_ONLY'
    score=make_score(bpm)
    xml=base.with_suffix('.musicxml');score.write('musicxml',fp=xml)
    midi=base.with_suffix('.mid');audit=make_midi(midi,bpm)
    results[label]=render(midi,base.with_suffix('.wav'))
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(base.with_suffix('.wav')),'-codec:a','libmp3lame','-b:a','320k',str(base.with_suffix('.mp3'))],check=True)
    (OUT/f'{label}_note_events.json').write_text(json.dumps(audit,indent=2))
(OUT/'audio-checks.json').write_text(json.dumps(results,indent=2))
shutil.copyfile(ROOT/'soundfonts/SalamanderGrandPiano-SF2-V3+20200602/readme.txt',OUT/'PIANO-SAMPLE-LICENSE.txt')
print(json.dumps(results,indent=2))
