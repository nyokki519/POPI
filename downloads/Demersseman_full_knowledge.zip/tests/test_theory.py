import unittest
from fractions import Fraction as F
from pathlib import Path
import tempfile
import sys
import xml.etree.ElementTree as E
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import theory as t
import mido

class ExactMusicTests(unittest.TestCase):
    def test_01_clefs_ledger_lines(self):
        self.assertEqual([t.diatonic_pitch('G',i) for i in [0,2,8,-2]],['E4','G4','F5','C4'])
        self.assertEqual([t.diatonic_pitch('F',i) for i in [0,6,8,-2]],['G2','F3','A3','E2'])
    def test_02_accidental_scope(self):
        local={};key={'B':-1,'E':-1,'A':-1}
        self.assertEqual(t.accidental_pitch('E',4,key,local),63)
        self.assertEqual(t.accidental_pitch('E',4,key,local,0),64)
        self.assertEqual(t.accidental_pitch('E',4,key,local),64)
        self.assertEqual(t.accidental_pitch('E',5,key,local),75)
        self.assertEqual(t.accidental_pitch('E',4,key,{}),63)
    def test_03_dots(self):
        self.assertEqual(t.duration('half',1),3)
        self.assertEqual(t.duration('eighth',2),F(7,8))
        self.assertEqual(t.duration('128th'),F(1,32))
    def test_04_tuplets(self):
        self.assertEqual(t.duration('eighth',actual=3,normal=2),F(1,3))
        self.assertEqual(15*t.duration('32nd',actual=15,normal=12),F(3,2))
    def test_05_compound_meter(self):
        self.assertEqual(t.bar_duration('6/8'),3)
        self.assertEqual(t.seconds(3,75),F(12,5))
    def test_06_chord_members(self):
        self.assertEqual([t.midi_pitch(x) for x in ['G3','C4','Eb4']],[55,60,63])
    def test_07_inversion_register(self):
        self.assertEqual([t.midi_pitch(x) for x in ['E3','G3','C4']],[52,55,60])
        self.assertNotEqual([52,55,60],[48,52,55])
    def test_08_voices_not_chord_sum(self):
        voice1=[F(1,2)]*6; voice2=[F(1,2),F(1,2),F(1),F(1)]
        self.assertEqual(sum(voice1),3);self.assertEqual(sum(voice2),3)
    def test_09_tenor_transpose(self):
        self.assertEqual(t.transpose_tenor('C5'),58)
        self.assertEqual(t.transpose_tenor('D5'),60)
        self.assertEqual(t.midi_pitch('C4'),60)
    def test_10_tempo_map_seconds(self):
        self.assertEqual(t.seconds(3,75)+t.seconds(3,120),F(39,10))
        self.assertEqual(t.seconds(3,60),F(3))
    def test_11_fermata_time(self):
        self.assertEqual(t.seconds(3,120)+F(2),F(7,2))
    def test_12_meter_change(self):
        self.assertEqual([t.bar_duration(x) for x in ['6/8','3/4','2/4']],[3,3,2])
    def test_13_repeats_endings(self):
        self.assertEqual(t.unfold_repeat([1,2],[3],[4]),[1,2,3,1,2,4])
    def test_14_pedal(self):
        self.assertEqual(t.pedal_extended_release(F(1),[(F(0),F(3))]),3)
        self.assertEqual(t.pedal_extended_release(F(4),[(F(0),F(3))]),4)
    def test_15_xml_midi_fixed_expected(self):
        xml=E.fromstring('<note><pitch><step>E</step><alter>-1</alter><octave>4</octave></pitch><duration>480</duration></note>')
        pitch=t.midi_pitch(xml.findtext('pitch/step')+'b'+xml.findtext('pitch/octave'))
        ticks=int(xml.findtext('duration'));mid=mido.MidiFile(ticks_per_beat=960)
        track=mido.MidiTrack();mid.tracks.append(track)
        track.append(mido.Message('note_on',note=pitch,velocity=64,time=0))
        track.append(mido.Message('note_off',note=pitch,time=ticks))
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'check.mid';mid.save(p);read=mido.MidiFile(p)
            self.assertEqual(read.tracks[0][0].note,63)
            self.assertEqual(read.tracks[0][1].time,480)
    def test_16_tremolo_measured(self):
        self.assertEqual(len(t.tremolo_offsets(F(3,2),3)),12)
        self.assertEqual(sum(d for _,d in t.tremolo_offsets(3,3)),3)
        self.assertEqual(len(t.tremolo_offsets(2,1)),4)
    def test_17_tie_vs_slur(self):
        # tie is one event across source segments; slur preserves two attacks.
        tied=[(F(0),F(6),67)];slurred=[(F(0),F(3),67),(F(3),F(3),67)]
        self.assertEqual(len(tied),1);self.assertEqual(len(slurred),2)
        self.assertEqual(tied[0][1],sum(x[1] for x in slurred))
    def test_18_enharmonic_spelling(self):
        self.assertEqual(t.midi_pitch('Cb4'),59)
        self.assertEqual(t.midi_pitch('B3'),59)
        self.assertEqual(t.midi_pitch('F##4'),67)

if __name__=='__main__':unittest.main(verbosity=2)
