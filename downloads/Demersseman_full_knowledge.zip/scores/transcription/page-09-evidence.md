# PDF 9 / engraved page 3 transcription evidence

Primary source: original A.S.164 PDF image `/workspace/audio-production/full-revision/source-images/pdf-09.png`. Sax staff was read only for the position of the free cadenza and not played or substituted.

Systems: 17–20, 21–23, 24–26, and unbarred cadenza span 27. Regular measures are 6/8, three quarter-note units. Every RH and LH event list totals 3 quarter-note units; the cadenza's nominal 3 units do **not** fix its fermata waits.

- 17: two marked 12-note tremolos, each dotted-quarter span; three beams, expanded as twelve 32nd attacks each. RH Bb3/D4 alternates with Ab3. LH Eb2/Eb3, eighth-note rests at offsets 1/2 and 2.
- 18: three-beam two-note dotted-half tremolo, 24 thirty-second attacks. RH Bb3/Eb4 alternates with G3; LH as 17.
- 19–20: seven RH attacks (16th, five eighths, 16th). 19 Db4 accidental applies through the first chord group; 20 A4 natural and F# bass octave are explicitly printed. Six bass eighths, half-bar pitch change.
- 21–22: eight RH attacks, each half-bar 16th/eighth/eighth/16th. Natural B4 in 21, natural A4 in 22, with explicit flat midway. Bass G# octave in 21, A to Bb octave in 22.
- 23: RH first Fb4/Ab4 dotted-quarter has two tremolo strokes, six repeated sixteenths. Six following explicit sixteenths. The following chord heads lie on the E4, G4, B4 lines: E4/Gb4/Bbb4, with single flat G and double-flat B. `23fullrh.png` resolves a prior octave/staff-position misreading. Independent page-10 agent and root confirmed the two explicit first-dyad flats and classified the middle trace as a printing artifact, not a note or rest. Bass is explicitly Cb3/Cb4, not B2/B3; see `23bass.png`.
- 24: first RH dotted-quarter tremolo is Eb4/G4/Bb4. The crowded signs are natural G and natural-flat B, canceling the preceding printed Gb and Bbb by courtesy; Eb4 remains from the key signature. Following explicit chords: E4/G4/C5 twice, F4/A4/C5, F4/A4/Db5, F4/Bb4/D5 twice. LH six Bb3 eighths. `24fullrh.png` retains all five treble lines for comparison.
- 25: RH Cb5/Eb5 alternates F#4, three beams across dotted half-notes: twenty-four 32nd attacks. LH A3 natural, then A#2, both dotted quarter. Source ledger/staff positions retained in `25full.png`.
- 26: six RH eighth chords ascend by printed voicing: G4/Bb4/Eb5; G3/Bb3/Eb4; Bb3/Eb4/G4; Eb4/G4/Bb4; G4/Bb4/Eb5; Bb4/Eb5/G5. LH twelve Bb2 attacks, six dotted-16th/32nd pairs. Upper rectangular marks are short third beams, **not F3 noteheads**, as seen in `26bass.png`.
- 27: first RH Bb4/D5/F5/Bb5 dotted-sixteenth, then D4/F4/Bb4 thirty-second, followed by the same chord quarter with fermata. Eighth rest with fermata across solo cadenza. Final RH Ab3/Bb3/D4 quarter has Ab3 written across onto the bass staff. LH Bb2 eighth, Bb1/Bb2 quarter fermata, eighth-rest fermata, then Bb1/Bb2 quarter fermata. Printed pitches and attack order are transcribed; actual cadenza/fermata seconds must be applied separately under user authorization. See `27rh.png`, `cad-new.png`, `new-r4.png`.

Measures 23 and 24 were corrected against crops retaining all five staff lines; independent comparison of all 17–27 spans by the page-10 agent and root confirmed the readings, with the first-dyad Fb4 correction applied. No repetition, DC, DS, volta, or coda appears on this page.
