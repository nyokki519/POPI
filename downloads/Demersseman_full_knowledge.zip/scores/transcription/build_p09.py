import json
from fractions import Fraction as F
from pathlib import Path
out=Path('/workspace/music-ai/scores/transcription/page-09.json')
data={'pdf_page':9,'measures':[],'issues':[]}
def add(i,sys,pos):
 m={'id':i,'meter':'6/8','duration_q':'3','key_fifths':-3,'events':[],'directions':[],'issues':[]};data['measures'].append(m);return m

def ev(m,staff,o,d,p,n=None,status='VERIFIED'):
 sys=1 if m['id']<=20 else 2 if m['id']<=23 else 3 if m['id']<=26 else 4
 pos=m['id']-16 if sys==1 else m['id']-20 if sys==2 else m['id']-23 if sys==3 else 1
 m['events'].append({'staff':staff,'voice':1,'offset_q':str(F(o)),'duration_q':str(F(d)),'pitches':p,'tie':None,'status':status,'source':{'pdf_page':9,'system':sys,'position':pos},'notation':n})
def trem(m,a,b,start,dur,unit):
 for k in range(int(F(dur)/F(unit))):ev(m,'RH',F(start)+k*F(unit),unit,a if k%2==0 else b,'Measured two-note tremolo expanded from source beams')
def save():out.write_text(json.dumps(data,ensure_ascii=False,indent=2))
for i in (17,18):
 m=add(i,1,i-16)
 if i==17:
  trem(m,['Bb3','D4'],['Ab3'],0,'3/2','1/8');trem(m,['Bb3','D4'],['Ab3'],'3/2','3/2','1/8')
 else:trem(m,['Bb3','Eb4'],['G3'],0,3,'1/8')
 for k in range(6):ev(m,'LH',F(k,2),'1/2',[] if k in (1,4) else ['Eb2','Eb3'])
 save()
for i,a,b,l1,l2 in [(19,['Bb3','Db4','G4'],['Ab3','C4','F4'],['E2','E3'],['F2','F3']),(20,['C4','Eb4','A4'],['Bb3','D4','G4'],['F#2','F#3'],['G2','G3'])]:
 m=add(i,1,i-16);o=F(0)
 for k,d in enumerate(['1/4','1/2','1/2','1/2','1/2','1/2','1/4']):ev(m,'RH',o,d,a if k<4 else b);o+=F(d)
 for k in range(6):ev(m,'LH',F(k,2),'1/2',l1 if k<3 else l2)
 m['directions']=[{'offset_q':'3/2' if i==19 else '0','text':'crescendo continuation'}];save()
for i,a,b,l1,l2 in [(21,['D4','F4','B4'],['D4','F4','Bb4'],['G#2','G#3'],['G#2','G#3']),(22,['D4','F4','A4'],['D4','F4','Ab4'],['A2','A3'],['Bb2','Bb3'])]:
 m=add(i,2,i-20);o=F(0)
 for k,d in enumerate(['1/4','1/2','1/2','1/4']*2):ev(m,'RH',o,d,a if k<4 else b);o+=F(d)
 for k in range(6):ev(m,'LH',F(k,2),'1/2',l1 if k<3 else l2)
 save()
m=add(23,2,3)
for k in range(6):ev(m,'RH',F(k,4),'1/4',['Fb4','Ab4'],'Dotted-quarter single-note 2-stroke tremolo; explicit flats on F4 and A4')
for k in range(6):ev(m,'RH',F(3,2)+F(k,4),'1/4',['E4','Gb4','Bbb4'],'Six source sixteenths with G-flat and B double-flat')
for k in range(6):ev(m,'LH',F(k,2),'1/2',['Cb3','Cb4'])
m['issues']=[]
m['directions']=[{'offset_q':'0','text':'f'}];save()
m=add(24,3,1)
for k in range(6):ev(m,'RH',F(k,4),'1/4',['Eb4','G4','Bb4'],'Dotted-quarter 2-stroke tremolo; G natural and B natural-flat courtesy cancellation')
for k,p in enumerate([['E4','G4','C5'],['E4','G4','C5'],['F4','A4','C5'],['F4','A4','Db5'],['F4','Bb4','D5'],['F4','Bb4','D5']]):ev(m,'RH',F(3,2)+F(k,4),'1/4',p)
for k in range(6):ev(m,'LH',F(k,2),'1/2',['Bb3'])
m['issues']=[]
m['directions']=[{'offset_q':'0','text':'pp'},{'offset_q':'3/2','text':'crescendo'}];save()
m=add(25,3,2)
trem(m,['Cb5','Eb5'],['F#4'],0,3,'1/8')
ev(m,'LH',0,'3/2',['A3']);ev(m,'LH','3/2','3/2',['A#2']);save()
m=add(26,3,3)
for k,p in enumerate([['G4','Bb4','Eb5'],['G3','Bb3','Eb4'],['Bb3','Eb4','G4'],['Eb4','G4','Bb4'],['G4','Bb4','Eb5'],['Bb4','Eb5','G5']]):ev(m,'RH',F(k,2),'1/2',p)
for k in range(6):
 ev(m,'LH',F(k,2),'3/8',['Bb2']);ev(m,'LH',F(k,2)+F(3,8),'1/8',['Bb2'])
m['directions']=[{'offset_q':'0','text':'f'}];save()
m=add(27,4,1);m['meter']='free';m['duration_q']='3'
ev(m,'RH',0,'3/8',['Bb4','D5','F5','Bb5'],'Dotted sixteenth in unbarred cadenza')
ev(m,'RH','3/8','1/8',['D4','F4','Bb4'],'Thirty-second in unbarred cadenza')
ev(m,'RH','1/2',1,['D4','F4','Bb4'],'Fermata')
ev(m,'RH','3/2','1/2',[],'Eighth rest with fermata; free sax cadenza; nominal duration only')
ev(m,'RH',2,1,['Ab3','Bb3','D4'],'Cross-staff Ab3, fermata; nominal duration only')
ev(m,'LH',0,'1/2',['Bb2'])
ev(m,'LH','1/2',1,['Bb1','Bb2'],'Fermata')
ev(m,'LH','3/2','1/2',[],'Eighth rest with fermata; nominal duration only')
ev(m,'LH',2,1,['Bb1','Bb2'],'Fermata')
m['directions']=[{'offset_q':'1/2','text':'fermata'},{'offset_q':'3/2','text':'fermata, sax cadenza; absolute wait to be assigned separately'},{'offset_q':'2','text':'fermata'}]
save()
