import json
from fractions import Fraction as F
from pathlib import Path
OUT=Path('/workspace/music-ai/scores/transcription')
measures=[]
def m(mid,sys,pos,key=-3):
 z={'id':mid,'meter':'6/8' if mid<32 else '3/4','duration_q':'3','key_fifths':key,'events':[],'directions':[],'issues':[]};measures.append(z);z['_source']={'pdf_page':10,'system':sys,'position':pos};return z
def ev(z,staff,offset,duration,pitches,notation=None):
 z['events'].append({'staff':staff,'voice':1,'offset_q':str(F(offset)),'duration_q':str(F(duration)),'pitches':pitches,'tie':None,'status':'VERIFIED','source':dict(z['_source']),'notation':notation})
def seq(z,staff,groups,durs):
 t=F(0)
 for pitches,d in zip(groups,durs):ev(z,staff,t,d,pitches);t+=F(d)
 assert t==3,(z['id'],staff,t)
def dy(z,t,v):z['directions'].append({'offset_q':str(F(t)),'type':'dynamic','value':v})
def repeat_chord(z,staff,pitches):
 ev(z,staff,0,'1/2',pitches);ev(z,staff,'1/2','1/4',pitches);ev(z,staff,'3/4','1/4',pitches)
 for t in [1,F(3,2),2,F(5,2)]:ev(z,staff,t,'1/2',pitches,'Measured one-slash half-note repetition: four eighths over beats 2–3')
for mid,pos in [(28,1),(30,3)]:
 z=m(mid,1,pos)
 seq(z,'RH',([['Bb3','Eb4']] if mid==28 else [['B3','D4']])+[['G4','G5']]*10,['1/2']+['3/8','1/8']*5)
 seq(z,'LH',([['D2','Bb2','G3']] if mid==28 else [['G2']])+[['G2','G3']]*5,['1/2']*6)
 dy(z,'1/2' if mid==28 else 0,'ff' if mid==28 else 'f')
for mid,pos,rh in [(29,2,[['D4','F#4'],['C#4','E4'],['C4','Eb4'],['B3','D4'],['C4','Eb4'],['A3','C4']]),(31,4,[['D4','F4','Ab4'],['C#4','E4','G4'],['C4','Eb4','G4'],['B3','D4','F4'],['Ab3','Db4','E4'],['G3','C4','Eb4']])]:
 z=m(mid,1,pos);seq(z,'RH',rh,['1/2']*6)
 for i in range(24):ev(z,'LH',F(i,8),'1/8',['G2'] if i%2==0 else ['G3'],'Two-note three-beam dotted-half tremolo: total three quarter beats, alternating thirty-seconds')
 dy(z,0,'p' if mid==29 else 'pp')
 z['directions'].append({'offset_q':'0','type':'slur','value':'RH through entire bar'})
z=m(32,2,1)
ev(z,'RH',0,'1/2',['B3','D4']);ev(z,'RH','1/2','1/4',['B3','D4','G4']);ev(z,'RH','3/4','1/4',['B3','D4','G4'])
for t in [1,F(3,2),2,F(5,2)]:ev(z,'RH',t,'1/2',['B3','D4','G4'],'One-slash half-note repetition')
repeat_chord(z,'LH',['G2','G3']);z['directions']+=[{'offset_q':'0','type':'tempo_text','value':'Allegretto'},{'offset_q':'0','type':'expression','value':'Légèrement'}]
for mid,pos,chord in [(33,2,['C4','Eb4','A4']),(34,3,['D4','F4','Ab4','B4']),(35,4,['Eb4','G4','C5'])]:
 z=m(mid,2,pos);repeat_chord(z,'RH',chord);repeat_chord(z,'LH',['G2','G3'])
z=m(36,3,1);seq(z,'RH',[['D4','G4','B4'],['Bb3','D4','G4'],['Bb3','D4','G4'],['D4','G4','B4'],['D4','G4','B4'],['G4','B4','D5']],['3/4','1/4']*3);seq(z,'LH',[['G2','G3'],['G3'],['G3'],['D3'],['D3'],['B2']],['3/4','1/4']*3);dy(z,0,'f')
z=m(37,3,2);seq(z,'RH',[['G4','B4','D5','F5'],[],[]],[1,1,1]);seq(z,'LH',[['G2'],[],[]],[1,1,1])
for mid,pos in [(38,3),(39,4)]:
 z=m(mid,3,pos);ev(z,'RH',0,3,[],'Whole-measure rest while saxophone plays');ev(z,'LH',0,3,[],'Whole-measure rest while saxophone plays')
for mid,sys,pos,chord in [(40,3,5,['G3','C4','E4']),(41,4,1,['G3','C4','E4']),(42,4,2,['A3','D4','F4']),(43,4,3,['B3','D4','F4','G4']),(44,4,4,['C4','E4','G4']),(45,4,5,['C#4','E4','G4','Bb4']),(46,4,6,['D4','F4','A4'])]:
 z=m(mid,sys,pos,0);repeat_chord(z,'RH',chord);seq(z,'LH',[['C3'],[],[],[]],['1/2','1/2',1,1])
 if mid==40:dy(z,0,'pp');z['directions'].append({'offset_q':'0','type':'tempo_text','value':'BOLERO'})
measures.sort(key=lambda z:z['id'])
for z in measures:
 z.pop('_source')
 for staff in ['RH','LH']:
  es=sorted([e for e in z['events'] if e['staff']==staff],key=lambda e:F(e['offset_q']));t=F(0)
  for e in es:assert F(e['offset_q'])==t,(z['id'],staff,e);t+=F(e['duration_q'])
  assert t==3,(z['id'],staff,t)
assert [z['id'] for z in measures]==list(range(28,47))
(OUT/'page-10.json').write_text(json.dumps({'pdf_page':10,'measures':measures,'issues':[]},ensure_ascii=False,indent=2))
print('19 measures,',sum(len(z['events']) for z in measures),'events; RH/LH contiguous and 3 quarter beats each')
