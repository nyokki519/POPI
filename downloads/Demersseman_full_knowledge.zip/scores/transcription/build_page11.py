import json
from fractions import Fraction as F
from pathlib import Path
out=Path('/workspace/music-ai/scores/transcription/page-11.json')
ms=[]
def M(n,sys,pos):
 m=dict(id=n,meter='3/4',duration_q='3',key_fifths=0,events=[],directions=[],issues=[]);m['_src']=dict(pdf_page=11,system=sys,position=pos);ms.append(m);return m
def e(m,staff,o,d,p,notation=None,tie=None):
 m['events'].append(dict(staff=staff,voice=1,offset_q=str(F(o)),duration_q=str(F(d)),pitches=p.split() if isinstance(p,str) else p,tie=tie,status='VERIFIED',source=m['_src'],notation=notation))
def bol(m,ch,half=None):
 for o,d in [('0','1/2'),('1/2','1/4'),('3/4','1/4')]:e(m,'RH',o,d,ch)
 for i in range(4):e(m,'RH',str(F(1)+F(i,2)),'1/2',half or ch,'one-stroke half-note measured tremolo, expanded as four eighths')
 e(m,'LH','0','1/2','C3');e(m,'LH','1/2','1/2',[]);e(m,'LH','1','1',[]);e(m,'LH','2','1',[])
def alt(m,ch,lo,hi):
 for i in range(6):
  t=F(i,2);e(m,'RH',str(t),'1/4',[]);e(m,'RH',str(t+F(1,4)),'1/4',ch)
  e(m,'LH',str(t),'1/4',lo if i%2==0 else hi);e(m,'LH',str(t+F(1,4)),'1/4',[])
bol(M(47,1,1),'D4 F4 G4 B4','D4 F4 G4 A4')
bol(M(48,1,2),'E4 G4 C5')
alt(M(49,1,3),'D4 A4 C5','F#3','D3')
alt(M(50,1,4),'E4 G4 B4','A3','D3')
alt(M(51,2,1),'C4 F#4 C5','A3','D3')
m=M(52,2,2)
for o,d,ch,lh in [('0','1/2','D4 G4 B4','G2'),('1/2','1/4','B3 D4 G4','G3'),('3/4','1/4','B3 D4 G4','G3'),('1','1/2','B3 D4 G4','G3'),('3/2','1/2','D4 G4 B4','D3'),('2','1/2','G4 B4 D5','B2'),('5/2','1/2','B4 D5 G5','G2')]:e(m,'RH',o,d,ch);e(m,'LH',o,d,lh)
m['directions'].append(dict(offset_q='0',type='dynamic',value='f'))
alt(M(53,2,3),'D4 A4 C5','F#3','D3');ms[-1]['directions'].append(dict(offset_q='0',type='dynamic',value='p'))
alt(M(54,2,4),'E4 G4 B4','A3','D3')
def save():
 clean=[{k:v for k,v in m.items() if k!='_src'} for m in ms]
 out.write_text(json.dumps(dict(pdf_page=11,measures=clean,issues=[]),ensure_ascii=False,indent=2))
m=M(55,3,1)
for o,d,ch,lh in [('0','1/2','D4 F4 A4 C5','C2'),('1/2','1/4','C#4','C#3'),('3/4','1/4','D4','D3'),('1','1/4','E4','E3'),('5/4','1/4','D4','D3'),('3/2','1/4','C4','C3'),('7/4','1/4','B3','B2'),('2','1/2','A3','A2'),('5/2','1/2','C4 E4 G4','D3')]:e(m,'RH',o,d,ch);e(m,'LH',o,d,lh)
m['directions'].append(dict(offset_q='0',type='dynamic',value='f'))
m=M(56,3,2)
for i in range(6):e(m,'RH',str(F(i,2)),'1/2','G3 B3 D4 F4 A4','dotted-half chord with one-stroke tremolo expanded as six eighths')
e(m,'LH','0','1/2','G2');e(m,'LH','1/2','1/2',[]);e(m,'LH','1','1',[]);e(m,'LH','2','1',[])
m['directions'] += [dict(offset_q='0',type='dynamic',value='pp'),dict(offset_q='0',type='tempo_text',value='presses un peu')]
for n,ch in [(57,'C4 Eb4 Ab4'),(58,'D4 F4 B4')]:
 m=M(n,3,n-54);e(m,'RH','0','1/2',[]);e(m,'RH','1/2','1/2',ch)
 for i in range(4):e(m,'RH',str(F(1)+F(i,2)),'1/2',ch,'half-note with one-stroke tremolo expanded as four eighths')
 e(m,'LH','0','1','G2');e(m,'LH','1','1',[]);e(m,'LH','2','1',[])
 if n==57:m['directions'].append(dict(offset_q='0',type='dynamic',value='p'))
m=M(59,3,5)
for i in range(3):
 e(m,'RH',str(i),'1/2',[]);e(m,'RH',str(F(i)+F(1,2)),'1/2','Eb4 G4 C5');e(m,'LH',str(i),'1/2','G2');e(m,'LH',str(F(i)+F(1,2)),'1/2',[])
m['directions'].append(dict(offset_q='0',type='tempo_text',value='rall.'))
m=M(60,4,1)
e(m,'RH','0','2','D4 G4 C5 E5',tie='start');e(m,'RH','2','1/2','D4 G4 C5 E5',tie='stop');e(m,'RH','5/2','1/2',[])
e(m,'LH','0','2','G2',tie='start');e(m,'LH','2','1/2','G2',tie='stop');e(m,'LH','5/2','1/2',[])
m['directions'].append(dict(offset_q='0',type='fermata',value='both staves half chord'))
m=M(61,4,2)
for o,d in [('0','1/2'),('1/2','1/4'),('3/4','1/4')]:e(m,'RH',o,d,'G3 C4 E4')
for i in range(4):
 e(m,'RH',str(F(1)+F(i,2)),'1/2','Ab3 C#4 G4','half-note measured eighth tremolo; independent source reread confirmed A3/C4 ledger placement')
# independent review by finish_p08 confirms the two low ledger heads
e(m,'LH','0','3','C2 C3','dotted-half octave');m['directions'].append(dict(offset_q='0',type='tempo_text',value='Tempo'))
m=M(62,4,3)
for o,d in [('0','1/2'),('1/2','1/4'),('3/4','1/4')]:e(m,'RH',o,d,'A3 D4 F4')
for i in range(4):e(m,'RH',str(F(1)+F(i,2)),'1/2','D4 F4 A4','half-note measured eighth tremolo expanded')
e(m,'LH','0','3','C2 C3','dotted-half octave')
m=M(63,4,4)
for o,d in [('0','1/2'),('1/2','1/4'),('3/4','1/4')]:e(m,'RH',o,d,'B3 D4 F4 G4')
for i in range(4):e(m,'RH',str(F(1)+F(i,2)),'1/2','B3 D4 F4 G4','half-note measured eighth tremolo expanded')
e(m,'LH','0','3','C2 C3','dotted-half octave')
for n,ch in [(64,'C4 E4 G4'),(65,'C4 Eb4 G4')]:
 m=M(n,4,n-59)
 for o,d in [('0','1/2'),('1/2','1/4'),('3/4','1/4')]:e(m,'RH',o,d,ch)
 for i in range(4):e(m,'RH',str(F(1)+F(i,2)),'1/2',ch,'half-note measured eighth tremolo expanded')
 if n==64:e(m,'LH','0','3','C2 C3','dotted-half octave')
 else:e(m,'LH','0','1','C3');e(m,'LH','1','1',[]);e(m,'LH','2','1',[])
save()

