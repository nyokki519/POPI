# Original PDF 13 (printed 7) source comparison

17 numbered spans: systems 79–81,82–84,85–89,90–95. Piano staves alone were transcribed; sax was inspected only for bar-duration/rest alignment. Key signature zero flats/sharps throughout this page; all accidentals were read on piano staff.

Staff line spacing is approximately6.8px at original1024px width, rather than10px. Slanted horizontal systems require local staff-line reference. In system3, m85/89 RH is D4 F4 A4. m86 RH D4 F4 G4 B4; m87 RH E4 G4 C5; m88 initial C4 E4 G4 C5 then C#4 E4 G4 Bb4. No chord-name reconstruction was used.

m79/83 dottedhalf stemslash is measured eighth repetition. m80 has quarter C4 Eb4 C5 followed two-note three-beam tremolo Eb4 A4 versus C4 through beats2–3; LH F#2,A2,C3 quarters. m81 first two beats retain three-beam tremolo; LH Eb3,F#3,A3 quarters. Last beat has an Eb4/F#4 chord with partial subsidiary beams followed C4 and isolated numeral8. This historical beam/octave shorthand remains unresolved and must not be certified for synthesis.

m84 Presto/ff; LH C2/C3 dottedhalf two-note three-beam tremolo continues through90. Curve between different pitches is a slur, not an equal-pitch tie. RH first beat eighth+two16ths; remaining half has one stemslash, expanded eighth repetition. m91 LH C2 then C3 E3 G3 twice. m92 RH C5 E5 G5 C6, A4 C5 E5 G5, E4 G4 C5 E5 quarters; LH C2,E2,G2 quarters.

m93 RH: quarter C4 E4 G4 C5; historical quarterrest; eighthrest;16rest;16chord G4 C5 E5. m94 first chord G4 C5 E5 is a hollow half, not quarter; then eighthrest,16rest,16chord E4 G4 C5. Sax printed half in94 independently corroborates the duration. LH93/94 tremolo reverses orientation C3→C2.

m95 RH E4 G4 C5; LH C2 C3, dottedhalf fermata, heavy final doublebar. Three right-hand dots and two left-hand dots are augmentation, not repeat dots.

All34 staff event durations currently total3quarter units. This is a structural check only and does not resolve m81 interpretation. m81 pitches at last beat are readable; interpretation of extra beams and isolated8 requires additional historical notation evidence.

## Resolution of m81 compressed figure (independent reread)

Direct comparison of original PDF8m16, PDF9m17, PDF12m77 and PDF13m81 establishes that the subsidiary partial beams abbreviate measured alternating tremolo. PDF8m16 labels the dotted-quarter span12; three subdivisions give12thirty-second attacks. PDF13m81 labels the quarter span8, giving8thirty-second attacks. The numeral is centered under the abbreviated pair and is not an ottava line; no octave shift or octave doubling is present. PDF12m77 displays the identical last-beat figure. RH finalbeat is therefore8attacks at1/8quarter each, alternating Eb4F#4 chord andC4. Both endpoints retain their printed octaves. This source-comparative interpretation agrees with the root reader's independent reading. Generic two-note tremolo semantics are documented by W3C MusicXML4.0 https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/tremolo/; numeral count interpretation is established by these original-score parallel figures, not inferred from harmony.

The earlier m81 unresolved note is superseded by this resolution; JSON issues are cleared and measured attacks are expanded explicitly. All34 staff spans remain3quarters.
