import json
from fractions import Fraction as F
from pathlib import Path
out=Path('/workspace/music-ai/scores/transcription/page-12.json')
data={'pdf_page':12,'measures':[],'issues':[]}
def measure(i):
 s=1 if i<70 else 2 if i<73 else 3 if i<76 else 4
 first={1:66,2:70,3:73,4:76}[s]
 m={'id':i,'meter':'3/4','duration_q':'3','key_fifths':0,'events':[],'directions':[],'issues':[]}
 m['_source']={'pdf_page':12,'system':s,'position':i-first+1};data['measures'].append(m);return m
 def_dummy=None
def ev(m,staff,o,d,p,notation=None):
 m['events'].append({'staff':staff,'voice':1,'offset_q':str(F(o)),'duration_q':str(F(d)),'pitches':p,'tie':None,'status':'VERIFIED','source':dict(m['_source']),'notation':notation})
def rep(m,staff,start,total,step,p,notation=None):
 o=F(start)
 for _ in range(int(F(total)/F(step))):ev(m,staff,o,step,p,notation);o+=F(step)
def alt(m,start,total,p,q):
 for n in range(int(F(total)*8)):
  ev(m,'RH',F(start)+F(n,8),F(1,8),p if n%2==0 else q,'two-note tremolo, three strokes; written values divided by two, expanded to 32nds')
def save():
 for m in data['measures']:m.pop('_source',None)
 out.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
m=measure(66)
for k in range(3):
 ev(m,'RH',k,'1/2',[]);ev(m,'RH',F(k)+F(1,2),'1/2',['Ab3','Db4','F4'] if k==0 else ['Ab3','Db4','Ab4'])
 ev(m,'LH',k,'1/2',['F3']);ev(m,'LH',F(k)+F(1,2),'1/2',[])
m=measure(67)
for o,d in [('0','1/2'),('1/2','1/4'),('3/4','1/4')]:ev(m,'RH',o,d,['B3','D4','F4','G4'])
rep(m,'RH',1,2,'1/2',['B3','D4','F4','G4'],'half-note chord, single slash measured eighth tremolo')
ev(m,'LH',0,3,['G2','G3']);m['directions']=[{'offset_q':'0','type':'accent','staff':'RH'}]
for i in (68,69):
 m=measure(i)
 rep(m,'RH',0,2,'1/2',['C4','E4','G4'],'half-note single slash' if i==69 else None)
 rep(m,'RH',2,1,'1/2',['C4','E4','A4']);rep(m,'LH',0,2,'1/2',['C3'],'half-note single slash' if i==69 else None);rep(m,'LH',2,1,'1/2',['A2'])
 m['directions']=[{'offset_q':'2','type':'accent','staff':'both'}]
 if i==68:m['directions'].insert(0,{'offset_q':'0','type':'dynamic','value':'p','staff':'RH'})
m=measure(70);ev(m,'RH',0,3,['Db4','F4','Ab4']);ev(m,'LH',0,3,['Db3']);m['directions']=[{'offset_q':'0','type':'diminuendo','end_offset_q':'1','staff':'RH'}]
for i in (71,):
 m=measure(i)
 for o,p in [(0,['A3','F4','G4']),('1/2',['A3','F4','G4']),(1,[]),('3/2',['A3','F4','G4']),(2,[]),('5/2',['A3','F4','G4'])]:ev(m,'RH',o,'1/2',p)
 ev(m,'LH',0,1,['D3']);ev(m,'LH',1,1,['G2']);ev(m,'LH',2,1,['D3'])
for i in (72,73):
 m=measure(i);rep(m,'RH',0,2,'1/2',['C4','E4','G4'],'half-note chord single slash');rep(m,'RH',2,1,'1/2',['C4','E4','A4']);rep(m,'LH',0,2,'1/2',['C3'],'half-note single slash');rep(m,'LH',2,1,'1/2',['A2']);m['directions']=[{'offset_q':'2','type':'accent','staff':'both'}]
m=measure(74);rep(m,'RH',0,3,'1/2',['Db4','F4','Ab4'],'dotted-half chord single slash');ev(m,'LH',0,3,['Db3']);m['directions']=[{'offset_q':'0','type':'diminuendo','end_offset_q':'1','staff':'RH'}]
m=measure(75)
for o,p in [(0,['A3','F4','G4']),('1/2',['A3','F4','G4']),(1,[]),('3/2',['A3','F4','G4']),(2,[]),('5/2',['A3','F4','G4'])]:ev(m,'RH',o,'1/2',p)
ev(m,'LH',0,1,['D3']);ev(m,'LH',1,1,['G2']);ev(m,'LH',2,1,['G2'])
m=measure(76);alt(m,0,3,['Eb4','A4'],['C4'])
for k,p in enumerate(['F#2','A2','C3']):ev(m,'LH',k,1,[p])
m['directions']=[{'offset_q':'0','type':'dynamic','value':'f','staff':'RH'}]
m=measure(77);alt(m,0,2,['Eb4','A4'],['C4']);alt(m,2,1,['Eb4','F#4'],['C4'])
for k,p in enumerate(['Eb3','F#3','G3']):ev(m,'LH',k,1,[p])
m=measure(78);rep(m,'RH',0,3,'1/2',['C4','D4','F4','A4'],'dotted-half four-note chord single slash; natural F4');rep(m,'LH',0,3,'1/2',['G3'],'dotted-half single slash')
# Each independent voice must cover the entire measure with no gaps or overlap.
for m in data['measures']:
 for staff in ['RH','LH']:
  events=sorted([e for e in m['events'] if e['staff']==staff],key=lambda e:F(e['offset_q']))
  end=F(0)
  for e in events:assert F(e['offset_q'])==end,(m['id'],staff,end,e);end+=F(e['duration_q'])
  assert end==3,(m['id'],staff,end)
save()
print(out, len(data['measures']),sum(len(m['events']) for m in data['measures']))
