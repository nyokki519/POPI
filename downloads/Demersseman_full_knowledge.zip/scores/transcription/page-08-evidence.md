# A.S.164 — PDF8 / printed page2 transcription evidence

Source: original uploaded PDF, extracted 1024px source image `pdf-08.png`.
Scope: anacrusis0 and regular6/8 spans1–16; source systems1–4.
All filled events marked VERIFIED were read directly from the piano staves. Empty pitch arrays in those events represent actual engraved rests. Unresolved spans contain issues, not substituted rests or harmonic reconstructions.

## Source features checked

- Pickup has two flags: sixteenth, quarter-note duration1/4. RH G4 G5, LH G2 G3.
- Bars1–2 dotted-half octaves are tied. The visible curves between different notes elsewhere were not converted to ties.
- Bar3 six eighth-note chords G3 C4 Eb4. LH eighth C3, then eighth rest and two quarter rests.
- Bars4,7,8,12 use a single stem stroke on dotted-half chords. Transcription expands six measured eighth repetitions, rather than rendering one sustained chord. Bar11 final dottedquarter and both halves of13 similarly expand three repetitions each.
- Bars5 and6–10 include cross-staff RH notes engraved on the bass staff; their pitches are read in bass clef.
- Bar5 Gb2 and F2 are different bass pitches, therefore no tie was recorded between them.
- Bar6 Bb1 dottedquarter tied to eighth, followed by a quarter rest.
- Bar11 B3 natural applies through the bar. Bar13 B3 natural applies until the subsequent C4/Eb4 chord.
- Bar12 LH F2 dottedhalf has a trill and termination grace notes E2-natural,F2; bar14 LH D2 has trill and C#2,D2 termination. Grace/trill meaning is preserved in notation and directions. They have not been silently replaced with unmarked regular durations.
- Bar14 arpeggiated RH eighth is Bb3 D4 F4 Ab4, followed by eighth,quarter,quarter rests.
- The mark near the midpoint of bar15 is fz, not a tuplet numeral.
- The numeral12 over bar16's last abbreviated32nd pair represents12 alternating attacks filling the final dottedquarter1.5q. Its total measure duration remains3q.

## Independent review / resolved details

- Bars9–10: RH cross-staff accidentals and ledger-note positions have now been transcribed, with REVIEW_REQUIRED retained pending independent comparison. M9 RH Gb3 Bb3 D4 ×3, then G3 A3 D#4 ×2, then F#3 A3 E4; LH Eb3 dottedquarter, Eb3 quarter, D3 eighth. M10 RH F#3 A3 E4 measured tremolo; LH D3 dottedquarter tied to eighth then quarter rest. Original enlargement `p08-m9-grid.png` and `p08-m9.png` are supplied; `p08-m9-labeled.png` is only an exploratory grid and NOT pitch evidence because staff curvature/ledger spacing makes a fixed-position overlay unreliable.
- Bars15–16: RH pitches were resolved by counting actual engraved ledger lines rather than assuming uniform vertical spacing. M15 groups1–3 Eb4 G4 with Bb3,Bb3,B3-natural; groups4–5 Eb4 G4 with C4; group6 D4 F4 with Bb3. M16 groups1–2 C4 G4 with A3-natural, group3 C4 F4 with A3-natural, final12 attacks alternate C4/A3-natural. Inspection images: `p08-m15begin.png`, `p08-m15end.png`, `p08-m16.png`.
- Bars15–16 LH eighth-note rhythm is directly read at offsets0,1,1.5,2.5 with eighth rests at.5 and2. Bar15 first note Eb2 only; subsequent octaves Eb2/Eb3 then final D2/D3. Bar16 all four attacks D2/D3.

No full-audio or whole-page certification is claimed by this transcription.

## Timing audit

Bothstaff voice1 totals were independently summed with exact Fraction arithmetic: pickup0 is1/4q, every span1–16 is3q. No approximate rounding or gate shortening was used. The source grace-note/trill realizations remain performance-level work for the central renderer.

Independent source comparison by finish_p12 confirmed m9/m10 chromatic RH voicings and m16. It corrected m15 groups4–5 to Eb4 G4 (not Eb4 Ab4) and finalgroup to D4 F4. These corrections were applied to JSON after viewing fullstaff crop; narrowcrop exposed only4stafflines and caused one-line indexing error.

Independent finish_p12 also confirmed m9 LH Eb3 dottedquarter/Eb3 quarter/D3 eighth with slur (not tie), and m10 LH D3 dottedquarter tied eighth plus quarter rest. REVIEW_REQUIRED issues9/10 were cleared following this comparison. All17 spans now contain bothstaff events without unresolved pitch issues.

Independent finish_p09 and root fullbassstaff comparison corrected bars13–14 main LH to D2 (head below E2 ledger, not on it). Bar14 termination is C#2,D2. Applied to JSON including trill direction.
