# PDF 10 / printed page 4 piano source comparison

Direct source: A.S.164, original `pdf-10.png`, source row crops and additional p10-* detailed crops. 19 spans 28–46, two piano staves, original concert pitch, no local clef changes. 28–31 6/8; 32–46 3/4. Key signature -3 through 39; natural cancellation at Boléro 40, zero fifths.

Source comparison corrections to inherited draft:
- 31 first upper chord is D4 F4 Ab4 (explicit flat at A4), not A4. Fifth is Ab3 Db4 E4, and sixth G3 C4 Eb4 (explicit G3 natural), as ledger positions in p10-31 / p10-31grid demonstrate. Previous draft's Bb3 / A3 were ledger counting errors.
- 36 first and fourth/fifth chord top is B4 natural, not Bb4. Printed natural at B4 persists within the bar. Second/third chord low Bb3 remains Bb because octave-specific accidental scope. Last RH G4 B4 D5. LH G2+G3, G3, G3, D3, D3, B2 natural.
- 40–46 LH heads were separately checked against each local bass staff: all C3, although apparent pixel heights vary with page slope. No harmony inference used to retain these repeated C3 heads.

28 RH Bb3 Eb4 opening, followed by five dotted-sixteenth/thirty-second octave G4 G5 pairs. LH D2 Bb2 G3 then five G2 G3 eighth attacks. 30 RH B3 D4 opening followed by same octave pairs; LH G2 single first, then G2 G3.
29/31 LH has two dotted-half heads G2 and G3 with three connecting beams, expanded as alternating 32nds for a complete three-quarter-beat span, 24 attacks. RH six separate eighth chords and marked slur.
32–35 Allegretto LH G2 G3 repeatedly; RH first 32 attack B3 D4 and subsequent attacks add G4. One-slash half notes at both staves are measured eight-note repetitions, four attacks over beats 2–3, following eighth + two sixteenths.
37 RH G4 B4 D5 F5 quarter then two quarter rests; LH G2 quarter then matching rests. 38/39 whole-bar piano rests while sax cue runs: retained as complete spans.
40–46 RH source chords individually checked: G3 C4 E4; G3 C4 E4; A3 D4 F4; B3 D4 F4 G4; C4 E4 G4; C#4 E4 G4 Bb4; D4 F4 A4. All have eighth + two sixteenths + one-slash half repetition. LH C3 eighth, eighth rest, two quarter rests.

Program validation: every RH/LH voice contiguous from 0 to 3 quarter beats; all 19 spans present. 249 source-expanded events. Status VERIFIED denotes this direct source head/rhythm comparison; global final certification remains the integrator's responsibility. No sax events included.
