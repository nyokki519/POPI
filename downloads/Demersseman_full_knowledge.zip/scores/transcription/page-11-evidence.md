# PDF 11 / printed page 5 — piano source transcription

Source: original A.S.164 PDF11, `/workspace/audio-production/full-revision/source-images/pdf-11.png`.
19 sequential printed spans: system1 47–50, system2 51–54, system3 55–59, system4 60–65.
All are 3/4, piano key signature zero sharps/flats. Sax cue uses two sharps and is excluded from events.

`page-11.json` records Fraction-compatible offsets/durations and spelled pitches. Every RH and LH voice covers exactly three quarter notes without gaps or overlap. One-stroke half/dotted-half measured tremolos are expanded into four/six eighth attacks; engraving evidence is recorded in each event's notation. No stochastic shortening or timing displacement.

## Specific source readings

- 47 opening D4 F4 G4 B4; tremolo changes top B4 to A4, retains D4 F4 G4.
- 48 E4 G4 C5.
- 49–51 and 53–54 show TWO flags on alternating RH chords and LH notes, therefore sixteenth-note/rest pairs, not eighth pairs.
- 52 low ledger pitches distinguish the G-major arpeggio data from a superficially similar C-major figure. D4 G4 B4 → B3 D4 G4 (three attacks) → D4 G4 B4 → G4 B4 D5 → B4 D5 G5.
- 55 RH chromatic scalar notes copied individually; first C4 sharp, subsequent C4 natural. LH corresponding C3 sharp/natural. Last chord C4 E4 G4, last LH D3.
- 56 open chord has FIVE heads: G3 B3 D4 F4 A4, dotted-half with one stroke. Evidence `p11-ch56-nearest.png`, `p11-ch56-correct.png`.
- 57 flats on E4 and A4, chord C4 Eb4 Ab4.
- 58 natural upper B4, chord D4 F4 B4.
- 59 piano RH eighth rests BEFORE each Eb4 G4 C5 eighth chord; LH G2 eighth BEFORE each eighth rest. Rallentando printed.
- 60 D4 G4 C5 E5 half-note tied to eighth, final eighth rest. LH G2 similarly tied. Fermata applies to initial chord.
- 61 half tremolo Ab3 C#4 G4. Crowded ledger reading independently reviewed by agent finish_p08; low head on A3 ledger, middle on C4 ledger, upper one oval on G4. Earlier uncertain alternatives were not retained.
- 62 initial A3 D4 F4: A3 on second ledger, printed natural cancels previous Ab3. Half changes to D4 F4 A4. Independent finish_p08 source review confirmed.
- 63 initial and half B3 D4 F4 G4: one C4 ledger above B3 head, no A3 ledger through head; F4/G4 heads displaced. Independent finish_p08 review corrected uniform-grid reading.
- 64–65 final cells have source-specific pitches. Separate full-page audit requested from finish_p08.
- 61–64 LH dotted-half C2 C3 octaves. 65 LH C3 quarter followed by two quarter rests.

## Caution for grids

Earlier `p11-grid.png` overlays do not reliably align with original staff lines. The source has horizontal slope/curvature and ledger spacing varies; nominal uniform extrapolation cannot replace actual printed ledger positions. New `p11-r*-slope.png`/local images are aids, not independent pitch evidence. Final decisions use original printed staves, ledger-line count and external peer reading, not expected harmony.

Mathematical validation: all 19 measures, each staff contiguous offsets 0–3, duration totals 3. This is distinct from the pending second full source audit.
