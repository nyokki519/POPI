# A.S.164 PDF 12 / printed 6 source comparison

13 consecutive 3/4 spans 66–78. Original piano treble/bass staves only; key signature remains 0. All RH/LH voices cover 3 quarter units independently, no gap/overlap; Fraction validator in write_p12.py passes.

- 66: RH first offbeat Ab3 Db4 F4, subsequent offbeats Ab3 Db4 Ab4; LH F3 eighths alternating eighth rests. Two printed flats apply Ab3/Db4; upper Ab4 explicitly printed before second chord.
- 67: RH four-note B3 D4 F4 G4; B3 and D4 printed natural, explicit eighth + two sixteenths + half-note single-slash shorthand. LH G2/G3 dotted half. Opening accent.
- 68–69: RH C4 E4 G4 for beats 1–2, C4 E4 A4 final beat; LH C3 for beats 1–2 then A2. 68 writes eighths; 69 writes half-note single slash. p begins 68, accents final beats.
- 70: dotted-half RH Db4 F4 Ab4, LH Db3. Both upper/lower flats are below their immediately higher staff line: RH Ab4 is between B4 and G4, Db4 below E4; LH Db3 on D3 line. Do not substitute Eb-major voicing. Diminuendo wedge.
- 71: RH A3 F4 G4 eighths at 0, 1/2, 3/2, 5/2, rests at 1 and 2. LH D3(natural), G2, D3 quarters.
- 72–73: half-note C4 E4 G4 single slash, final two eighth C4 E4 A4. LH C3 single-slash half followed A2 eighths. Final-beat accents.
- 74 RH Db4 F4 Ab4 dotted-half single slash: six eighth-note attacks; LH Db3 remains held dotted half without slash, diminuendo. Independent audit identified this attack distinction from 70 (no RH slash); corrected after rechecking p12-74.png.
- 75 has RH same as 71, LH D3(natural), G2, G2 quarters.
- 76: RH dotted-half pair Eb4/A4 alternating C4, three-stroke two-note tremolo for 3 quarters; LH F#2, A2, C3 quarters. f begins.
- 77: RH half-note pair Eb4/A4 alternating C4 (2 quarters), black quarter-note pair Eb4/F#4 alternating C4 for remaining beat, three-stroke tremolo. All three beams are tremolo strokes: applying another ordinary-eighth subdivision would incorrectly leave a half-beat gap. LH Eb3, F#3, G3 quarters.
- 78: RH four-note C4 D4 F4 A4 dotted-half single slash (F4 natural printed); LH G3 dotted-half single slash. Expanded as six eighth-note attacks each hand.

Tremolos are expanded into performed events with no speculative harmony. Original shorthand retained in each event notation. No pedal sign visible on these piano systems. Sax cresc./f/ff belong to sax staff and are not copied as piano dynamics.

Visual evidence: p12-piano1..4.png plus individual p12-67..78.png; original full source pdf-12.png. High zoom crops p12-67-raw.png and p12-78-rh-full.png establish ledger positions and four-note final chord. p12-final-full.png shows three-stroke two-note tremolos.
