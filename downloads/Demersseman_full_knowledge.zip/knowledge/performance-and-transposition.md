# Performance, harmony and transposition

## Harmony is an error detector, not a note generator

A pitch-class chord label cannot determine octave, inversion, duplicated notes,
inner voices, passing notes or bass register. A C-minor chord may be voiced in
many ways. Enter each head from the score; only afterwards use harmonic analysis
to identify suspicious readings. Dissonant chromatic sonorities are not errors
merely because they violate a guessed chord progression. Compare source heads,
accidental scope and voice-leading rather than substituting conventional chords.

## B-flat tenor saxophone

Modern B-flat tenor sounds14 semitones (a major ninth) below its written note:
written C5 (MIDI72) sounds Bb3 (MIDI58). The piano is written at concert pitch
and must not be transposed. Check the actual nineteenth-century score's key and
octave conventions; a matching key signature alone does not verify every note.
This edition begins sax1flat versus piano3flats, consistent with this relation.
Only piano events enter the render channels.

## Tempo and ensemble

Andante/Allegretto/Presto are qualitative indications, not unique BPM values.
Record beat unit with every numeric choice. At dotted-quarter50, quarter BPM=75;
one6/8 bar lasts2.4 seconds. Tempo changes act on a shared score timeline, not
separate drifting hand tracks. In a fixed accompaniment, the player must know
the cadenza and fermata cue times. Extra wait seconds are performance choices,
not additional source notes. Stable and80% versions use the same pitch/rhythm
master. At0.8 tempo, metric duration scales1.25.

## Piano expression and audio

Velocity selects/weights samples and is not a linear acoustic decibel value.
Dynamics should follow the printed directions while inner/low voices retain
audible balance. Preserve note onsets and written durations during expression
processing. Sustain pedal (CC64) can lengthen sample decay independently of the
MIDI note-off; use explicit notation or a clearly documented interpretation,
without excessive harmonic blur. Slurs and ties have different event effects.
Record staccato and accents; do not globally shorten every note as 'humanizing'.

The existing Salamander Grand Piano SF2 is Yamaha C5 sampling with multiple
velocity layers, Alexander Holm/FreePats, CC BY3.0. The SF2 conversion has fewer
mechanical/pedal extras than the original SFZ. FluidSynth at44.1kHz, dry stereo,
24-bit WAV and FFmpeg MP3 at320kbps are available. Check sample peaks, finite
values, sustained tails, first/last event alignment and channel programs.
Check encoding/replay independently of asserting that the transcription is right.

## Romantic context and limits

Demersseman (1833–1866) was a French nineteenth-century composer and flautist.
This source is the1866 Adolphe Sax A.S.164 tenor work, not the A.S.163 alto solo.
Printed legato, expressive dynamics and contrasting dance articulation supply
the performance evidence. No modern-edition changes or recording-specific
rubato are adopted without comparison. General Romantic style does not justify
adding notes, rolls, rhythmic alterations or unprinted transitions.
