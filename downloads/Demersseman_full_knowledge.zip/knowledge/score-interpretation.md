# Score interpretation and error checks

These are reusable interpretation rules. Applying them to a particular image
does not by itself certify that its notes have been read correctly.

## Staff, clef, pitch and accidentals

Treble G clef places G4 on line2 (counting upwards). Bass F clef places F3 on
line4. Every adjacent line/space advances one diatonic letter; ledger lines
continue that sequence. Scientific octave changes between B and C. Cross-staff
notes use the clef of the staff on which the head is drawn; hand/staff is an
independent performance assignment. Staff slope must be accounted for when
reading old scans. Do not propagate an OMR-invented clef change.

A key signature supplies default accidentals by letter. An explicit accidental
normally applies to that letter and octave until the barline (with editorial
ambiguities recorded rather than silently normalized). A natural cancels the
key alteration. Tied notes continuing into the next bar retain their pitch.
Neither a new system nor a new page resets the key signature. Accidentals in
different octaves and simultaneous voices need explicit source inspection.

## Duration and metre

Quarter note =1. Whole=4, half=2, eighth=1/2, sixteenth=1/4,
32nd=1/8, 64th=1/16, 128th=1/32. One dot multiplies by3/2; two by7/4.
A tuplet of n in the time of m scales each written duration by m/n.
Use fractions throughout; convert to floating-point seconds only for audio.
6/8 has3 quarters per full bar and ordinarily two dotted-quarter beats;
3/4 also has3 quarters but three quarter beats. Equal bar duration does not
make their accent or beat unit interchangeable. Pickup duration is explicit
and does not require sounded padding. A whole-bar rest follows the actual
bar length, even when its visual rest sign looks like a four-quarter rest.

A tie joins identical pitches into one sounding event; the original segment
boundaries remain in the score. A slur does not suppress subsequent attacks.
Grace timing is an interpretation and must be recorded; do not add grace notes
from recordings. Independent voices are checked independently, with explicit
rests/forwards rather than summed chord-member durations.

## Repetition shorthand, tremolo and ornaments

A one-stroke single-note tremolo subdivides its written span into eighths;
two strokes into sixteenths; three into32nds. Ordinary beams/flags on short
notes may form part of the total subdivision, so inspect the actual notation.
Two-note measured tremolo alternates its two endpoints across a single total
span; both endpoint note values describe that span. A displayed dotted-half
pair must not be played as two successive dotted halves.

MusicXML's tremolo documentation states: for double-note tremolos, each note's
duration is half the displayed duration. Retain endpoint spelling/voicing and
source duration while expanding the implied attacks for MIDI. A small '12'
over abbreviated alternating figures must be interpreted from the actual
figure and metre; never assume it is an ordinary12-tuplet or copy the sax line.
Trill, turn, octave indication and fermata require separate source evidence.
Distinguish abbreviation beams from actual full beaming and tuplet numerals.

## Structure and transcription evidence

End double bars are not repeat bars without repeat dots in the required staff
positions. Chord augmentation dots are not repeat dots. Voltas, D.C., D.S.,
Coda and repeat signs must be located before playback expansion. Source-layout
span numbering is separate from regular playback-bar numbering, especially
at the unbarred cadenza.

Keep {page,system,position}, hand, voice, note spelling, accidental, octave,
Fraction onset/duration, tie and articulation for every event. VERIFIED means
direct original-image comparison; INFERRED means an interpretation; UNREADABLE
means an image cannot be resolved; MISSING means the required source is absent.
An unreviewed automatic recognition is not VERIFIED.

References retrieved for this session are listed in research/source-access.json.
