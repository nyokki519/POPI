"""Verified source -> explicit performance MusicXML -> independently read MIDI.

No OMR result is used here. Fractions are preserved until MIDI tempo encoding
or audio sample allocation. Original per-page records remain immutable inputs.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import copy
import csv
import hashlib
import json
import math
import xml.etree.ElementTree as E
import mido
from theory import midi_pitch, pitch_parts, BASE_DURATION

ROOT=Path(__file__).resolve().parents[1]
DIVISIONS=9600
VELOCITY={'ppp':27,'pp':38,'p':49,'mp':58,'mf':68,'f':83,'ff':99,'fff':110,'fz':96,'sfz':96}

def sub(parent,tag,value=None,**attrs):
    node=E.SubElement(parent,tag,{k:str(v) for k,v in attrs.items()})
    if value is not None:node.text=str(value)
    return node

def load_source():
    measures=[];pages=[]
    for page in range(8,14):
        path=ROOT/'scores/transcription'/f'page-{page:02}.json'
        data=json.loads(path.read_text());measures.extend(data['measures'])
        pages.append({'pdf_page':page,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    measures.sort(key=lambda m:m['id'])
    if [m['id'] for m in measures]!=list(range(96)):
        raise ValueError('The pickup and all95 source spans must be present exactly once')
    return measures,pages

def validate(measures):
    rows=[];errors=[]
    for m in measures:
        target=F(m['duration_q']); voices=defaultdict(list)
        if m.get('issues'):errors.append({'id':m['id'],'issues':m['issues']})
        for event in m['events']:
            if event.get('status')!='VERIFIED':errors.append({'id':m['id'],'unverified':event})
            if F(event['duration_q'])<=0:errors.append({'id':m['id'],'nonpositive_duration':event})
            voices[(event['staff'],event.get('voice',1))].append(event)
            for pitch in event['pitches']:
                if not 21<=midi_pitch(pitch)<=108:errors.append({'id':m['id'],'outside_piano':pitch})
        for staff in ['RH','LH']:
            if not any(k[0]==staff for k in voices):errors.append({'id':m['id'],'missing_staff':staff})
        for (staff,voice),events in voices.items():
            cursor=F(0)
            for event in sorted(events,key=lambda e:F(e['offset_q'])):
                offset=F(event['offset_q'])
                if offset!=cursor:errors.append({'id':m['id'],'staff':staff,'voice':voice,'expected':str(cursor),'actual':str(offset)})
                cursor=offset+F(event['duration_q'])
            if cursor!=target:errors.append({'id':m['id'],'staff':staff,'voice':voice,'end':str(cursor),'target':str(target)})
            rows.append({'source_span':m['id'],'pdf_page':events[0]['source']['pdf_page'],
                'staff':staff,'voice':voice,'meter':m['meter'],'duration_quarters':str(cursor),
                'events':len(events),'note_heads':sum(len(e['pitches']) for e in events),
                'source_status':'VERIFIED','mathematical_check':'PASS' if cursor==target else 'FAIL'})
    return rows,errors

def realize_ornaments(measures):
    out=copy.deepcopy(measures)
    choices=[]
    for m in out:
        if m['id'] not in (12,14):continue
        principal,upper,termination=('F2','G2',['E2','F2']) if m['id']==12 else ('D2','Eb2',['C#2','D2'])
        old=[e for e in m['events'] if e['staff']=='LH']
        if len(old)!=1 or old[0]['pitches']!=[principal] or F(old[0]['duration_q'])!=3:
            raise ValueError(f'Trill source changed at{m["id"]}; inspect instead of guessing')
        m['events']=[e for e in m['events'] if e['staff']!='LH']
        for i in range(20):
            event=copy.deepcopy(old[0]);event.update(offset_q=str(F(i,8)),duration_q='1/8',pitches=[principal if i%2==0 else upper],tie=None,
                notation='Source trill realized as alternating32nds; source total duration unchanged')
            m['events'].append(event)
        for i,pitch in enumerate(termination):
            event=copy.deepcopy(old[0]);event.update(offset_q=str(F(5,2)+F(i,4)),duration_q='1/4',pitches=[pitch],tie=None,
                notation='Printed small termination note, realized within the end of the trill')
            m['events'].append(event)
        choices.append({'span':m['id'],'source_principal':principal,'upper':upper,
            'termination':termination,'trill_subdivision_quarters':'1/8',
            'termination_subdivision_quarters':'1/4','status':'INFERRED_RATE_VERIFIED_NOTATION_AND_PITCHES'})
    return out,choices

def offsets(measures):
    starts={};cursor=F(0)
    for m in measures:starts[m['id']]=cursor;cursor+=F(m['duration_q'])
    return starts,cursor

def tempo_points(measures,version):
    starts,total=offsets(measures);scale=F(4,5) if version=='practice_80percent' else F(1)
    values={F(0):F(75),starts[32]:F(100),starts[40]:F(120),starts[84]:F(160)}
    # The printed free-cadenza fermatas have producer-authorized fixed waits.
    values[starts[27]+F(1,2)]=F(15)      #1q =4 seconds
    values[starts[27]+F(3,2)]=F(5)       #1/2q silent cue =6 seconds
    values[starts[27]+F(2)]=F(20)        #1q =3 seconds
    values[starts[28]]=F(75)
    if version=='original_performance':
        for i in range(9):values[starts[56]+i]=F(120)+F(12*i,9)
        for i,bpm in enumerate([132,112,92]):values[starts[59]+i]=F(bpm)
    # Bar60: tied half+eighth held3.25 seconds, then eighth rest0.25 seconds.
    values[starts[60]]=F(600,13)
    values[starts[60]+F(5,2)]=F(120)
    values[starts[61]]=F(120)
    # Final dotted-half fermata held3 seconds; renderer adds a2.5s decay tail.
    values[starts[95]]=F(60)
    return [(offset,bpm*scale) for offset,bpm in sorted(values.items())]

def absolute_seconds(position,points):
    elapsed=F(0);previous=F(0);bpm=points[0][1]
    for offset,value in points[1:]:
        if offset>=position:break
        elapsed+=(offset-previous)*60/bpm;previous=offset;bpm=value
    return elapsed+(position-previous)*60/bpm

def note_type(duration):
    for kind,base in BASE_DURATION.items():
        for dots in range(3):
            if base*sum((F(1,2**i) for i in range(dots+1)),F())==duration:return kind,dots
    raise ValueError(f'Unsupported exact note duration{duration}; do not quantize')

def direction_type(d):
    kind=d.get('type','text')
    value=direction_value(d)
    return 'dynamic' if kind=='text' and value in VELOCITY else 'crescendo' if kind=='text' and value=='crescendo' else kind

def direction_value(d):return str(d.get('value',d.get('text','')))

def dynamic_levels(measures):
    starts,_=offsets(measures);changes=[(F(0),49)];ramps=[];open_ramp=None
    for m in measures:
        for d in sorted(m.get('directions',[]),key=lambda d:F(d.get('offset_q','0'))):
            q=starts[m['id']]+F(d.get('offset_q','0'));kind=direction_type(d);value=direction_value(d)
            if kind=='dynamic':changes.append((q,VELOCITY.get(value,49)))
            if kind in ('crescendo','diminuendo','decrescendo'):
                if value=='stop':
                    if open_ramp:ramps.append((*open_ramp,q));open_ramp=None
                else:
                    if open_ramp:ramps.append((*open_ramp,q))
                    open_ramp=(q,1 if kind=='crescendo' else -1)
                    if d.get('end_offset_q'):
                        ramps.append((*open_ramp,starts[m['id']]+F(d['end_offset_q'])));open_ramp=None
    if open_ramp:
        later=[q for q,_ in changes if q>open_ramp[0]]
        ramps.append((*open_ramp,min(later) if later else open_ramp[0]+3))
    changes.sort(key=lambda x:x[0])
    def level(mid,offset):
        q=starts[mid]+F(offset);current=49
        for position,value in changes:
            if position>q:break
            current=value
        for begin,sign,end in ramps:
            if begin<=q<end and end>begin:current+=sign*18*float((q-begin)/(end-begin))
        return current
    return level

def write_xml(measures,path,version='original_performance',source_notation=False):
    starts,total=offsets(measures);points=tempo_points(measures,version);levels=dynamic_levels(measures)
    score=E.Element('score-partwise',version='4.0')
    work=sub(score,'work');sub(work,'work-title','Premier Solo, Andante et Boléro — piano accompaniment')
    identification=sub(score,'identification');sub(identification,'creator','Jules Demersseman',type='composer')
    sub(identification,'rights','Original1866 A.S.164 public-domain score; piano-sample license separately credited')
    encoding=sub(identification,'encoding');sub(encoding,'software','Source-checked Fraction-based piano transcription')
    partlist=sub(score,'part-list');spart=sub(partlist,'score-part',id='P1');sub(spart,'part-name','Piano')
    si=sub(spart,'score-instrument',id='I1');sub(si,'instrument-name','Piano');sub(si,'instrument-abbreviation','Pno.')
    mi=sub(spart,'midi-instrument',id='I1');sub(mi,'midi-channel',1);sub(mi,'midi-program',1)
    part=sub(score,'part',id='P1');old_key=None;old_meter=None
    for m in measures:
        node=sub(part,'measure',number=m['id'],implicit='yes' if m['id'] in (0,27) else 'no')
        if m['id'] in (0,17,28,47,66,79):sub(node,'print',new_page='yes' if m['id']!=0 else 'no')
        # XML attribute names must use hyphens, not Python-friendly underscores.
        if node.find('print') is not None:
            pr=node.find('print');pr.set('new-page',pr.attrib.pop('new_page'))
        attributes=sub(node,'attributes');sub(attributes,'divisions',DIVISIONS)
        if m['key_fifths']!=old_key:
            key=sub(attributes,'key');sub(key,'fifths',m['key_fifths']);old_key=m['key_fifths']
        if m['meter']!=old_meter:
            time=sub(attributes,'time')
            if m['meter']=='free':sub(time,'senza-misura')
            else:
                beats,unit=m['meter'].split('/');sub(time,'beats',beats);sub(time,'beat-type',unit)
            old_meter=m['meter']
        if m['id']==0:
            sub(attributes,'staves',2)
            for number,sign,line in [(1,'G',2),(2,'F',4)]:
                clef=sub(attributes,'clef',number=number);sub(clef,'sign',sign);sub(clef,'line',line)
        xml_directions=copy.deepcopy(m.get('directions',[]))
        for d in m.get('directions',[]):
            if direction_type(d) in ('crescendo','diminuendo','decrescendo') and d.get('end_offset_q'):
                xml_directions.append(dict(d,offset_q=d['end_offset_q'],value='stop'))
        if m['id']==26:xml_directions.append({'type':'crescendo','value':'stop','offset_q':'0'})
        for d in xml_directions:
            kind=direction_type(d);value=direction_value(d)
            if kind=='barline':continue
            direction=sub(node,'direction',placement='above');dt=sub(direction,'direction-type')
            if kind=='dynamic' and value in VELOCITY:
                dynamics=sub(dt,'dynamics');sub(dynamics,value)
            elif kind in ('crescendo','diminuendo','decrescendo'):
                subtype='stop' if value=='stop' else 'crescendo' if kind=='crescendo' else 'diminuendo'
                sub(dt,'wedge',type=subtype,number=1)
            else:sub(dt,'words',f'{kind}: {value}')
            offset=F(d.get('offset_q','0'))
            sub(direction,'offset',int(offset*DIVISIONS));sub(direction,'staff',1 if d.get('staff','RH')=='RH' else 2)
        for offset,bpm in points:
            if starts[m['id']]<=offset<starts[m['id']]+F(m['duration_q']):
                direction=sub(node,'direction');dt=sub(direction,'direction-type')
                sub(dt,'words',f'Playback quarter={float(bpm):.6g} ({version}; fermata rates are timing choices)')
                sub(direction,'offset',int((offset-starts[m['id']])*DIVISIONS))
                sub(direction,'sound',tempo=float(bpm))
        groups=defaultdict(list)
        for event in m['events']:groups[(event['staff'],event.get('voice',1))].append(event)
        first=True
        for (staff,voice),events in sorted(groups.items()):
            if not first:sub(sub(node,'backup'),'duration',int(F(m['duration_q'])*DIVISIONS))
            first=False;staffnum=1 if staff=='RH' else 2
            global_voice=voice+(0 if staff=='RH' else 4)
            key_alters={letter:0 for letter in 'ABCDEFG'}
            for letter in ('BEADGCF'[:abs(m['key_fifths'])] if m['key_fifths']<0 else 'FCGDAEB'[:m['key_fifths']]):key_alters[letter]=-1 if m['key_fifths']<0 else 1
            accidental_state={}
            for event in sorted(events,key=lambda e:F(e['offset_q'])):
                kind,dots=note_type(F(event['duration_q']))
                pitches=event['pitches'] or [None]
                for index,pitch in enumerate(pitches):
                    n=sub(node,'note')
                    if pitch is None:sub(n,'rest',measure='yes' if F(event['duration_q'])==F(m['duration_q']) else 'no')
                    else:
                        if index:sub(n,'chord')
                        letter,alter,octave=pitch_parts(pitch);p=sub(n,'pitch');sub(p,'step',letter)
                        if alter:sub(p,'alter',alter)
                        sub(p,'octave',octave)
                    ticks=F(event['duration_q'])*DIVISIONS
                    if ticks.denominator!=1:raise ValueError('MusicXML divisions cannot represent exact duration')
                    sub(n,'duration',int(ticks))
                    tie=event.get('ties',{}).get(pitch,event.get('tie'))
                    tie_values=['stop','start'] if tie=='continue' else [tie] if tie else []
                    for value in tie_values:sub(n,'tie',type=value)
                    sub(n,'voice',global_voice);sub(n,'type',kind)
                    for _ in range(dots):sub(n,'dot')
                    if pitch:
                        prior=accidental_state.get((letter,octave),key_alters[letter])
                        if alter!=prior:sub(n,'accidental',{-2:'flat-flat',-1:'flat',0:'natural',1:'sharp',2:'double-sharp'}[alter])
                        accidental_state[(letter,octave)]=alter
                    sub(n,'staff',staffnum)
                    if tie_values or (pitch and 'fermata' in str(event.get('notation','')).lower()):
                        notations=sub(n,'notations')
                        for value in tie_values:sub(notations,'tied',type=value)
                        if 'fermata' in str(event.get('notation','')).lower():sub(notations,'fermata','normal')
                    if source_notation and m['id'] in (12,14) and staff=='LH' and pitch:
                        notations=n.find('notations')
                        if notations is None:notations=sub(n,'notations')
                        sub(sub(notations,'ornaments'),'trill-mark')
                    accent=any(direction_type(d)=='accent' and F(d.get('offset_q','0'))==F(event['offset_q']) and d.get('staff','both') in (staff,'both') for d in m.get('directions',[]))
                    arpeggio=pitch and 'arpeggio' in str(event.get('notation','')).lower()
                    if pitch and (accent or arpeggio):
                        notations=n.find('notations')
                        if notations is None:notations=sub(n,'notations')
                        if accent:sub(sub(notations,'articulations'),'accent')
                        if arpeggio:sub(notations,'arpeggiate')
                    play=sub(n,'play');sub(play,'other-play',max(1,min(127,round((levels(m['id'],event['offset_q'])+ (6 if any(direction_type(d)=='accent' and F(d.get('offset_q','0'))==F(event['offset_q']) and d.get('staff','both') in (staff,'both') for d in m.get('directions',[])) else 0))*(.9 if staff=='LH' else 1)))),type='midi-velocity')
        if source_notation and m['id'] in (12,14):
            for pitch in (['E2','F2'] if m['id']==12 else ['C#2','D2']):
                n=sub(node,'note');sub(n,'grace',slash='yes');letter,alter,octave=pitch_parts(pitch)
                p=sub(n,'pitch');sub(p,'step',letter)
                if alter:sub(p,'alter',alter)
                sub(p,'octave',octave);sub(n,'voice',5);sub(n,'type','16th');sub(n,'staff',2)
        if m['id']==95:sub(sub(node,'barline',location='right'),'bar-style','light-heavy')
    E.indent(score,space='  ')
    E.ElementTree(score).write(path,encoding='utf-8',xml_declaration=True)

def read_xml_events(path):
    """Independent XML cursor/backup/chord read, not reuse of source offsets."""
    root=E.parse(path).getroot();events=[];start=F(0);divisions=1;spans=[]
    for measure in root.findall('part/measure'):
        cursor=F(0);maximum=F(0);previous=F(0)
        local_div=measure.findtext('attributes/divisions')
        if local_div:divisions=int(local_div)
        for child in measure:
            if child.tag=='backup':cursor-=F(child.findtext('duration'))/divisions
            elif child.tag=='forward':cursor+=F(child.findtext('duration'))/divisions
            elif child.tag=='note':
                duration=F(child.findtext('duration','0'))/divisions
                chord=child.find('chord') is not None
                onset=previous if chord else cursor
                if not chord:previous=onset;cursor+=duration
                maximum=max(maximum,onset+duration)
                if child.find('rest') is None:
                    pitch=child.find('pitch');letter=pitch.findtext('step');alter=int(pitch.findtext('alter','0'));octave=int(pitch.findtext('octave'))
                    name=letter+('#'*alter if alter>0 else 'b'*(-alter))+str(octave)
                    staff=child.findtext('staff');events.append({'span':int(measure.get('number')),
                        'staff':'RH' if staff=='1' else 'LH','pitch':midi_pitch(name),'spelling':name,
                        'start':start+onset,'duration':duration,'ties':[t.get('type') for t in child.findall('tie')],
                        'velocity':int(child.findtext('play/other-play','64'))})
        spans.append({'id':int(measure.get('number')),'start':str(start),'duration':str(maximum)})
        start+=maximum
    return events,spans,start

def source_signature(measures):
    starts,_=offsets(measures);out=[]
    for m in measures:
        for event in m['events']:
            for pitch in event['pitches']:
                tie=event.get('ties',{}).get(pitch,event.get('tie'))
                ties=('start','stop') if tie=='continue' else (tie,) if tie else ()
                out.append((m['id'],event['staff'],midi_pitch(pitch),str(starts[m['id']]+F(event['offset_q'])),str(F(event['duration_q'])),tuple(sorted(ties))))
    return sorted(out)

def merge_ties(events):
    active={};out=[]
    for event in sorted(events,key=lambda e:(e['start'],e['staff'],e['pitch'])):
        key=(event['staff'],event['pitch'])
        if 'stop' in event['ties']:
            previous=active.get(key)
            if previous is None or previous['start']+previous['duration']!=event['start']:
                raise ValueError(f'Unmatched noncontiguous tie {event}')
            previous['duration']+=event['duration']
            if 'start' not in event['ties']:active.pop(key)
        else:
            copyevent=copy.deepcopy(event);out.append(copyevent)
            if 'start' in event['ties']:active[key]=copyevent
    if active:raise ValueError('Unclosed tie at end of score')
    return out

def write_midi(events,measures,path,version,total):
    mid=mido.MidiFile(type=1,ticks_per_beat=DIVISIONS);meta=mido.MidiTrack();mid.tracks.append(meta)
    meta.append(mido.MetaMessage('track_name',name='Piano accompaniment; complete source0-95'))
    starts,_=offsets(measures);changes=[]
    for offset,bpm in tempo_points(measures,version):
        micros=round(F(60000000)/bpm)
        if not 1<=micros<=16777215:raise ValueError('MIDI tempo exceeds24-bit limit')
        changes.append((int(offset*DIVISIONS),mido.MetaMessage('set_tempo',tempo=micros)))
    for mid_id,numerator,denominator in [(0,6,8),(32,3,4)]:
        changes.append((int(starts[mid_id]*DIVISIONS),mido.MetaMessage('time_signature',numerator=numerator,denominator=denominator)))
    for mid_id,key in [(0,'Cm'),(40,'C')]:changes.append((int(starts[mid_id]*DIVISIONS),mido.MetaMessage('key_signature',key=key)))
    previous=0
    for tick,message in sorted(changes,key=lambda x:x[0]):message.time=tick-previous;meta.append(message);previous=tick
    endtick=int(total*DIVISIONS);meta.append(mido.MetaMessage('end_of_track',time=endtick-previous))
    merged=merge_ties(events)
    for channel,staff in enumerate(['RH','LH']):
        track=mido.MidiTrack();mid.tracks.append(track)
        track.append(mido.MetaMessage('track_name',name='Piano '+staff))
        track.append(mido.Message('program_change',channel=channel,program=0))
        timeline=[]
        for event in merged:
            if event['staff']!=staff:continue
            start=int(event['start']*DIVISIONS);end=int((event['start']+event['duration'])*DIVISIONS)
            timeline.extend([(start,1,mido.Message('note_on',channel=channel,note=event['pitch'],velocity=event['velocity'])),
                             (end,0,mido.Message('note_off',channel=channel,note=event['pitch'],velocity=0))])
        previous=0
        for tick,_,message in sorted(timeline,key=lambda x:(x[0],x[1])):
            message.time=tick-previous;track.append(message);previous=tick
        track.append(mido.MetaMessage('end_of_track',time=endtick-previous))
    mid.save(path)
    return merged

def check_midi(path,expected,total):
    mid=mido.MidiFile(path);actual=[];active={};programs=[]
    for track in mid.tracks:
        tick=0
        for msg in track:
            tick+=msg.time
            if msg.type=='program_change':programs.append(msg.program)
            if msg.type=='note_on' and msg.velocity:
                key=(msg.channel,msg.note)
                if key in active:raise ValueError('Overlapping duplicate pitch in one hand')
                active[key]=(tick,msg.velocity)
            elif msg.type=='note_off' or (msg.type=='note_on' and not msg.velocity):
                onset,velocity=active.pop((msg.channel,msg.note))
                actual.append((msg.channel,msg.note,onset,tick-onset,velocity))
    target=sorted((0 if e['staff']=='RH' else 1,e['pitch'],int(e['start']*DIVISIONS),int(e['duration']*DIVISIONS),e['velocity']) for e in expected)
    if sorted(actual)!=target or active or any(p!=0 for p in programs):raise ValueError('MIDI events/programs do not exactly match XML')
    if max(sum(msg.time for msg in track) for track in mid.tracks)!=int(total*DIVISIONS):raise ValueError('MIDI does not reach final source span')
    return {'status':'PASS','note_attacks':len(actual),'programs':programs,'length_seconds':mid.length,'ticks_per_quarter':mid.ticks_per_beat}

def main():
    source,pages=load_source();rows,errors=validate(source)
    (ROOT/'reports/score-validation.json').write_text(json.dumps({'rows':rows,'errors':errors,'source_page_hashes':pages},indent=2))
    if errors:raise ValueError(f'{len(errors)} source-data problems remain; do not render')
    performance,ornaments=realize_ornaments(source);_,errors=validate(performance)
    if errors:raise ValueError(errors)
    (ROOT/'scores/verified/source-events.json').write_text(json.dumps(source,ensure_ascii=False,indent=2))
    (ROOT/'scores/verified/performance-events.json').write_text(json.dumps(performance,ensure_ascii=False,indent=2))
    (ROOT/'reports/ornament-realization.json').write_text(json.dumps(ornaments,indent=2))
    xml=ROOT/'output/verified_score.musicxml';write_xml(performance,xml)
    write_xml(source,ROOT/'output/source_notation.musicxml',source_notation=True)
    events,spans,total=read_xml_events(xml)
    actual=sorted((e['span'],e['staff'],e['pitch'],str(e['start']),str(e['duration']),tuple(sorted(e['ties']))) for e in events)
    if actual!=source_signature(performance):raise ValueError('MusicXML roundtrip changes source performance events')
    results={};timelines={}
    for version in ['original_performance','practice_stable','practice_80percent']:
        path=ROOT/'output'/('piano_accompaniment.mid' if version=='original_performance' else version+'.mid')
        expected=write_midi(events,performance,path,version,total);results[version]=check_midi(path,expected,total)
        points=tempo_points(performance,version);starts,_=offsets(performance)
        timelines[version]={'musical_end_seconds':float(absolute_seconds(total,points)),
            'tempo_points':[{'score_quarters':str(q),'quarter_BPM':str(bpm),'seconds':float(absolute_seconds(q,points))} for q,bpm in points],
            'source_span_start_seconds':{str(key):float(absolute_seconds(value,points)) for key,value in starts.items()}}
    (ROOT/'reports/xml-midi-validation.json').write_text(json.dumps({'source_spans':len(source),'xml_note_heads':len(events),'source_duration_quarters':str(total),'versions':results,'xml_roundtrip':'PASS'},indent=2))
    (ROOT/'reports/tempo-timelines.json').write_text(json.dumps(timelines,indent=2))
    with (ROOT/'reports/measure-verification.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
    print(json.dumps({'source_spans':len(source),'source_errors':0,'xml_note_heads':len(events),'versions':results},indent=2))

if __name__=='__main__':main()
