"""Exact musical arithmetic; independent fixed-answer tests live in tests/."""
from fractions import Fraction
import re

BASE = {'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
LETTERS = 'CDEFGAB'
BASE_DURATION = {'whole':Fraction(4), 'half':Fraction(2), 'quarter':Fraction(1),
                 'eighth':Fraction(1,2), '16th':Fraction(1,4),
                 '32nd':Fraction(1,8), '64th':Fraction(1,16), '128th':Fraction(1,32)}

def pitch_parts(value):
    m=re.fullmatch(r'([A-G])([#b]*)(-?\d+)',value)
    if not m: raise ValueError(value)
    letter, accidental, octave=m.groups()
    return letter, accidental.count('#')-accidental.count('b'), int(octave)

def midi_pitch(value):
    letter, alter, octave=pitch_parts(value)
    return 12*(octave+1)+BASE[letter]+alter

def diatonic_pitch(clef, staff_steps):
    # steps above the bottom line: trebleE4, bassG2.
    reference = 4*7+2 if clef=='G' else 2*7+4 if clef=='F' else None
    if reference is None: raise ValueError(clef)
    index=reference+staff_steps
    return LETTERS[index%7]+str(index//7)

def duration(note_type, dots=0, actual=1, normal=1):
    return BASE_DURATION[note_type]*sum((Fraction(1,2**i) for i in range(dots+1)),Fraction())*Fraction(normal,actual)

def bar_duration(meter):
    numerator, denominator=map(int,meter.split('/'))
    return Fraction(numerator*4,denominator)

def seconds(quarters, quarter_bpm):
    return Fraction(quarters)*60/Fraction(quarter_bpm)

def transpose_tenor(written):
    return midi_pitch(written)-14

def tremolo_offsets(span, strokes):
    span=Fraction(span); step=Fraction(1,2**strokes)
    if span%step:raise ValueError('Tremolo subdivision does not fill span')
    return [(i*step,step) for i in range(int(span/step))]

def accidental_pitch(letter, octave, key, local, explicit=None):
    if explicit is not None:local[(letter,octave)]=explicit
    alter=local.get((letter,octave),key.get(letter,0))
    return 12*(octave+1)+BASE[letter]+alter

def unfold_repeat(ids, first_ending, second_ending):
    return list(ids)+list(first_ending)+list(ids)+list(second_ending)

def pedal_extended_release(note_end, pedal_intervals):
    for start,end in pedal_intervals:
        if start<=note_end<end:return end
    return note_end
