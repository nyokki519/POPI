"""Verified piano MIDI -> dry Salamander WAV/MP3; bounded-memory audio.

Run: PYTHONPATH=/workspace/audio-production/python-libs python src/audio_renderer.py
  --midi INPUT.mid --wav OUTPUT.wav --mp3 OUTPUT.mp3 --report OUTPUT.json

SoundFont: Alexander Holm's Salamander Grand Piano V3 (Yamaha C5),
converted by Roberto / FreePats, CC BY 3.0. See bundled original readme.
This renderer validates conversion/audio only, never source-score correctness.
"""
from __future__ import annotations
import argparse
import ctypes as C
import hashlib
import json
import math
from pathlib import Path
import subprocess
import tempfile
import mido
import numpy as np
import soundfile as sf

RATE = 44100
TAIL_SECONDS = 2.5
BLOCK = 16384
FONT = Path('/workspace/audio-production/soundfonts/SalamanderGrandPiano-SF2-V3+20200602/SalamanderGrandPiano-V3+20200602.sf2')
TARGET_PEAK = 10 ** (-1 / 20)


def probe(path):
    return json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(path)]))


def audio_stats(path):
    """Decode with FFmpeg and inspect streamed float blocks, including MP3."""
    process = subprocess.Popen(['ffmpeg', '-v', 'error', '-i', str(path), '-f', 'f32le', '-acodec', 'pcm_f32le', '-ac', '2', '-ar', str(RATE), '-'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    peak = 0.; sumsquares = 0.; count = 0; clipped = 0
    while True:
        raw = process.stdout.read(BLOCK * 2 * 4)
        if not raw:
            break
        data = np.frombuffer(raw, dtype='<f4')
        if not np.isfinite(data).all():
            process.kill()
            raise ValueError(f'Nonfinite decoded audio: {path}')
        peak = max(peak, float(np.max(np.abs(data))))
        sumsquares += float(np.sum(data.astype(np.float64) ** 2))
        count += len(data)
        clipped += int(np.count_nonzero(np.abs(data) >= 1.))
    error = process.stderr.read().decode()
    if process.wait() != 0:
        raise RuntimeError(error)
    if not count or peak <= 0:
        raise ValueError(f'Empty or silent audio: {path}')
    return {'decoded_frames': count // 2, 'decoded_seconds': count / 2 / RATE,
            'peak': peak, 'rms': math.sqrt(sumsquares / count), 'clipped_samples': clipped,
            'all_samples_finite': True}


def render(midi_path, wav_path, mp3_path, report_path=None):
    midi_path, wav_path, mp3_path = map(Path, (midi_path, wav_path, mp3_path))
    for path in (wav_path, mp3_path):
        path.parent.mkdir(parents=True, exist_ok=True)
    lib = C.CDLL('libfluidsynth.so.3')
    ptr, integer, string = C.c_void_p, C.c_int, C.c_char_p
    def bind(name, result, args):
        function = getattr(lib, name); function.restype = result; function.argtypes = args
        return function
    settings = bind('new_fluid_settings', ptr, [])()
    synth = None
    try:
        setnum = bind('fluid_settings_setnum', integer, [ptr, string, C.c_double])
        setint = bind('fluid_settings_setint', integer, [ptr, string, integer])
        setnum(settings, b'synth.sample-rate', RATE)
        setnum(settings, b'synth.gain', .45)
        setint(settings, b'synth.reverb.active', 0)
        setint(settings, b'synth.chorus.active', 0)
        synth = bind('new_fluid_synth', ptr, [ptr])(settings)
        if not synth:
            raise RuntimeError('FluidSynth initialization failed')
        font_id = bind('fluid_synth_sfload', integer, [ptr, string, integer])(synth, str(FONT).encode(), 0)
        if font_id < 0:
            raise RuntimeError(f'Cannot load SoundFont: {FONT}')
        select = bind('fluid_synth_program_select', integer, [ptr, integer, integer, integer, integer])
        for channel in (0, 1):
            if select(synth, channel, font_id, 0, 0) != 0:
                raise RuntimeError('Cannot select piano program')
        noteon = bind('fluid_synth_noteon', integer, [ptr, integer, integer, integer])
        noteoff = bind('fluid_synth_noteoff', integer, [ptr, integer, integer])
        cc = bind('fluid_synth_cc', integer, [ptr, integer, integer, integer])
        pitchbend = bind('fluid_synth_pitch_bend', integer, [ptr, integer, integer])
        write = bind('fluid_synth_write_float', integer, [ptr, integer, ptr, integer, integer, ptr, integer, integer])
        midi = mido.MidiFile(midi_path)
        note_count = 0; elapsed = 0.; frame = 0; raw_peak = 0.
        with tempfile.TemporaryDirectory(prefix='piano-render-', dir=str(wav_path.parent)) as temporary:
            float_path = Path(temporary) / 'unscaled-float.wav'
            with sf.SoundFile(float_path, 'w', RATE, 2, subtype='FLOAT', format='WAV') as output:
                def samples(frames):
                    nonlocal raw_peak
                    while frames > 0:
                        n = min(frames, BLOCK)
                        left = np.zeros(n, dtype=np.float32); right = np.zeros(n, dtype=np.float32)
                        if write(synth, n, left.ctypes.data, 0, 1, right.ctypes.data, 0, 1) != 0:
                            raise RuntimeError('FluidSynth sample generation failed')
                        data = np.column_stack((left, right))
                        if not np.isfinite(data).all():
                            raise ValueError('Nonfinite generated samples')
                        raw_peak = max(raw_peak, float(np.max(np.abs(data))))
                        output.write(data)
                        frames -= n
                def dispatch(messages):
                    nonlocal note_count
                    # At the same sample, release old attacks before initiating new ones.
                    def priority(msg):
                        if msg.type == 'note_off' or (msg.type == 'note_on' and msg.velocity == 0): return 0
                        if msg.type == 'note_on': return 2
                        return 1
                    for msg in sorted(messages, key=priority):
                        if msg.is_meta: continue
                        if hasattr(msg, 'channel') and msg.channel not in (0, 1):
                            raise ValueError(f'Unexpected non-piano channel {msg.channel}')
                        if msg.type == 'note_on' and msg.velocity > 0:
                            noteon(synth, msg.channel, msg.note, msg.velocity); note_count += 1
                        elif msg.type == 'note_off' or msg.type == 'note_on':
                            noteoff(synth, msg.channel, msg.note)
                        elif msg.type == 'control_change':
                            cc(synth, msg.channel, msg.control, msg.value)
                        elif msg.type == 'program_change':
                            if msg.program != 0: raise ValueError('Only concert grand piano program 0 is allowed')
                            select(synth, msg.channel, font_id, 0, 0)
                        elif msg.type == 'pitchwheel':
                            if msg.pitch != 0: raise ValueError('Pitch bend would change source concert pitch')
                            pitchbend(synth, msg.channel, 8192)
                pending = []; pending_frame = 0
                for msg in midi:
                    elapsed += msg.time  # mido integrates the MIDI tempo map into seconds.
                    target = round(elapsed * RATE)
                    if target != pending_frame:
                        dispatch(pending)
                        samples(target - frame)
                        frame = target
                        pending = []
                        pending_frame = target
                    pending.append(msg)
                dispatch(pending)
                musical_frames = frame
                tail_frames = round(TAIL_SECONDS * RATE)
                samples(tail_frames)
                frame += tail_frames
            if raw_peak <= 0 or not note_count:
                raise ValueError('No audible piano attacks')
            normalization_gain = TARGET_PEAK / raw_peak
            with sf.SoundFile(float_path) as source, sf.SoundFile(wav_path, 'w', RATE, 2, subtype='PCM_24', format='WAV') as output:
                for data in source.blocks(blocksize=BLOCK, dtype='float64'):
                    output.write(data * normalization_gain)
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(wav_path), '-c:a', 'libmp3lame', '-b:a', '320k', str(mp3_path)], check=True)
        wav_stats = audio_stats(wav_path); mp3_stats = audio_stats(mp3_path)
        wav_info = sf.info(wav_path)
        if wav_info.samplerate != RATE or wav_info.channels != 2 or wav_info.subtype != 'PCM_24':
            raise ValueError(f'Incorrect WAV format: {wav_info}')
        if wav_info.frames != frame or wav_stats['decoded_frames'] != frame:
            raise ValueError('WAV duration does not match MIDI sample timeline')
        if abs(mp3_stats['decoded_frames'] - frame) > 2:
            raise ValueError('MP3 gapless decoded duration does not match WAV')
        if wav_stats['clipped_samples'] or mp3_stats['clipped_samples']:
            raise ValueError('Clipping detected in encoded output')
        result = {'midi': str(midi_path), 'wav': str(wav_path), 'mp3': str(mp3_path),
                  'midi_sha256': hashlib.sha256(midi_path.read_bytes()).hexdigest(),
                  'midi_seconds': elapsed, 'tail_seconds': TAIL_SECONDS,
                  'expected_seconds': elapsed + TAIL_SECONDS, 'frames': frame,
                  'musical_frames': musical_frames, 'note_on_count': note_count,
                  'sample_rate': RATE, 'channels': 2, 'wav_bit_depth': 24,
                  'raw_peak': raw_peak, 'normalization_gain': normalization_gain,
                  'target_peak_dbfs': -1, 'reverb': False, 'chorus': False,
                  'wav_validation': wav_stats, 'mp3_validation': mp3_stats,
                  'wav_probe': probe(wav_path), 'mp3_probe': probe(mp3_path),
                  'soundfont': {'path': str(FONT), 'title': 'Salamander Grand Piano V3',
                                'original_author': 'Alexander Holm', 'sf2_conversion': 'Roberto / FreePats',
                                'license': 'CC BY 3.0', 'source': 'https://freepats.zenvoid.org/Piano/acoustic-grand-piano.html'},
                  'validation_scope': 'MIDI timing and audio conversion only; source-note correctness is checked separately'}
        if report_path:
            report_path = Path(report_path); report_path.parent.mkdir(parents=True, exist_ok=True)
            report_path.write_text(json.dumps(result, indent=2, ensure_ascii=False))
        return result
    finally:
        if synth: bind('delete_fluid_synth', None, [ptr])(synth)
        bind('delete_fluid_settings', None, [ptr])(settings)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--midi', required=True)
    parser.add_argument('--wav', required=True)
    parser.add_argument('--mp3', required=True)
    parser.add_argument('--report')
    args = parser.parse_args()
    report = render(args.midi, args.wav, args.mp3, args.report)
    print(json.dumps({key: report[key] for key in ('frames', 'midi_seconds', 'expected_seconds', 'note_on_count', 'raw_peak')}, indent=2))


if __name__ == '__main__':
    main()
