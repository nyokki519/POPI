import AppKit
import CoreText
import CoreImage
import ImageIO
import Foundation
var failures=0
func check(_ name:String,_ condition:Bool) {print("\(condition ? "PASS":"FAIL") \(name)");if !condition {failures += 1;print("::error::"+name)}}
func room(width:Int,height:Int,withAvatar:Bool=true,withName:Bool=true,comment:String="こんばんは",keyboard:Bool=false,three:Bool=false,tint:CGFloat=0.98,bubbleColor:CGColor?=nil,whiteText:Bool=false)->CIImage {
    let color=CGColorSpaceCreateDeviceRGB()
    let cg=CGContext(data:nil,width:width,height:height,bitsPerComponent:8,bytesPerRow:width*4,space:color,bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue)!
    let w=CGFloat(width),h=CGFloat(height)
    func rect(_ x:CGFloat,_ y:CGFloat,_ rw:CGFloat,_ rh:CGFloat,_ color:CGColor) {cg.setFillColor(color);cg.fill(CGRect(x:x*w,y:(1-y-rh)*h,width:rw*w,height:rh*h))}
    func text(_ text:String,_ x:CGFloat,_ y:CGFloat) {
        let font=CTFontCreateWithName("HiraginoSans-W3" as CFString,w*0.041,nil)
        let attrs:[NSAttributedString.Key:Any]=[NSAttributedString.Key(kCTFontAttributeName as String):font,NSAttributedString.Key(kCTForegroundColorAttributeName as String):CGColor(gray:tint<0.5 || whiteText ? 1:0,alpha:1)]
        let line=CTLineCreateWithAttributedString(NSAttributedString(string:text,attributes:attrs))
        cg.textPosition=CGPoint(x:x*w,y:(1-y)*h);CTLineDraw(line,cg)
    }
    rect(0,0,1,1,CGColor(red:0.10,green:0.38,blue:0.48,alpha:1))
    if withName {text("テスト太郎",0.16,0.395)}
    rect(0.16,0.42,0.55,comment.contains("\n") ? 0.14:0.075,bubbleColor ?? CGColor(gray:tint,alpha:1))
    for (index,line) in comment.components(separatedBy:"\n").enumerated() {text(line,0.185,0.468+CGFloat(index)*0.035)}
    if withAvatar {cg.setFillColor(CGColor(red:0.86,green:0.67,blue:0.78,alpha:1));cg.fillEllipse(in:CGRect(x:0.047*w,y:(1-0.395)*h-0.043*w,width:0.086*w,height:0.086*w))}
    rect(0.025,0.28,0.60,0.075,CGColor(gray:0.98,alpha:1));text("公式アナウンス",0.045,0.33)
    rect(0.025,0.90,0.45,0.055,CGColor(gray:0.98,alpha:1));text("メッセージを送信",0.045,0.94)
    if keyboard {
        for row in 0..<3 {for col in 0..<9 {rect(0.02+CGFloat(col)*0.108,0.60+CGFloat(row)*0.09,0.085,0.065,CGColor(gray:0.98,alpha:1));text("あ",0.025+CGFloat(col)*0.108,0.645+CGFloat(row)*0.09)}}
    }
    if three {
        for (y,word) in [(CGFloat(0.58),"ありがとう"),(CGFloat(0.74),"よろしく")] {
            rect(0.16,y,0.55,0.075,CGColor(gray:y<0.7 ? tint:0.98,alpha:1))
            text("テスト花子",0.16,y-0.025)
            text(word,0.185,y+0.048)
            cg.setFillColor(CGColor(red:0.86,green:0.67,blue:0.78,alpha:1));cg.fillEllipse(in:CGRect(x:0.047*w,y:(1-y+0.025)*h-0.043*w,width:0.086*w,height:0.086*w))
        }
    }
    return CIImage(cgImage:cg.makeImage()!)
}
for (w,h) in [(750,1334),(1170,2532),(1290,2796)] {
 let processor=ChatFrameProcessor(broadReading:false)
 let input=room(width:w,height:h)
 let first=try processor.process(input,orientation:.up)
 check("native OCR \(w)x\(h) includes comment only",first.messages?.map{$0.text.replacingOccurrences(of:" ",with:"")} == ["こんばんは"])
 check("native layout has one avatar-backed bubble",first.bubbles==1)
 let cached=try processor.process(input,orientation:.up)
 check("unchanged frame performs no new OCR",cached.recognitions==0 && cached.messages?.count==1)
 let changed=try processor.process(room(width:w,height:h,comment:"ありがとう"),orientation:.up)
 check("changed text invalidates cache",changed.recognitions==1 && changed.messages?.first?.text.replacingOccurrences(of:" ",with:"")=="ありがとう")
 let keyboard=try processor.process(room(width:w,height:h,keyboard:true),orientation:.up)
 check("native keyboard text excluded",keyboard.messages?.map{$0.text.replacingOccurrences(of:" ",with:"")} == ["こんばんは"])
}
let noAvatar=try ChatFrameProcessor(broadReading:false).process(room(width:750,height:1334,withAvatar:false),orientation:.up)
print("::notice::No-avatar native candidates: \(noAvatar.messages?.map{$0.text} ?? [])")
check("native announcement without avatar excluded",noAvatar.messages?.isEmpty==true)
let animated=ChatFrameProcessor(broadReading:false)
var completed=false
for i in 0..<4 {
    let frame=try animated.process(room(width:750,height:1334,three:true,tint:0.90+CGFloat(i)*0.025),orientation:.up)
    check("per-frame OCR limit remains two",frame.recognitions<=2)
    if let messages=frame.messages,messages.count==3 {completed=true}
}
check("animated upper bubbles cannot starve third message",completed)
let rotate=room(width:750,height:1334)
let rotated=try ChatFrameProcessor(broadReading:false).process(rotate.oriented(forExifOrientation:8),orientation:.right)
check("rotated sample returns upright chat",rotated.messages?.first?.text.replacingOccurrences(of:" ",with:"")=="こんばんは")
for (message,expectedWords) in [("@しおちゃん おかえりー！",["しおちゃん","おかえり"]),("@ぱやみ 多分2人は\nおこちゃまなんだよ",["ぱやみ","おこちゃまなんだよ"])] {
 let sample=room(width:1170,height:2532,comment:message)
 let extracted=try ChatFrameProcessor(broadReading:false).process(sample,orientation:.up)
 let body=normalizeComment(extracted.messages?.first?.text ?? "").replacingOccurrences(of:" ",with:"")
 print("::notice::Synthetic mention OCR bubbles=\(extracted.bubbles) count=\(extracted.messages?.count ?? -1) text=\(body)")
 check("mentioned user and message body retained: \(expectedWords[0])",expectedWords.allSatisfy{body.contains($0)})
}
for tint:CGFloat in [0.22,0.72] {
 let dark=try ChatFrameProcessor(broadReading:false).process(room(width:750,height:1334,tint:tint),orientation:.up)
 check("gray bubble native OCR \(tint)",dark.messages?.first?.text.replacingOccurrences(of:" ",with:"")=="こんばんは")
 let noIcon=try ChatFrameProcessor(broadReading:false).process(room(width:750,height:1334,withAvatar:false,tint:tint),orientation:.up)
 check("gray bubble without avatar is excluded \(tint)",noIcon.messages?.isEmpty==true)
}
for color in [CGColor(red:0.8,green:0.05,blue:0.6,alpha:1),CGColor(red:0.02,green:0.25,blue:0.7,alpha:1),CGColor(red:0.10,green:0.38,blue:0.48,alpha:1)] {
 let sample=room(width:1170,height:2532,bubbleColor:color,whiteText:true)
 let result=try ChatFrameProcessor(broadReading:false).process(sample,orientation:.up)
 check("colored or unoutlined body OCR, actual \(result.messages?.map{$0.text} ?? [])",result.messages?.first?.text.replacingOccurrences(of:" ",with:"")=="こんばんは")
}
for (w,h) in [(750,1334),(1170,2532),(1290,2796)] {
 let processor=ChatFrameProcessor(broadReading:false)
 let sample=room(width:w,height:h,withName:false,comment:"こんばんは\nまた来ます")
 let frame=try processor.process(sample,orientation:.up)
 let text=frame.messages?.first?.text.replacingOccurrences(of:" ",with:"") ?? ""
 check("missing name native multiline \(w)x\(h)",frame.messages?.count==1 && text.contains("こんばんは") && text.contains("また来ます"))
 let detector=CommentDetector(filterSystemLabels:false,liveMode:true)
 _=detector.ingest(frame.messages ?? [],now:0)
 check("native selected message reaches live speech candidates",detector.ingest(frame.messages ?? [],now:1).count==1)
}
// Legacy strict-path checks above are retained separately. The default shipped
// path below deliberately accepts announcements and has no avatar prerequisite.
for (w,h) in [(750,1334),(1170,2532),(1290,2796)] {
 let processor=ChatFrameProcessor(lightweight:false)
 let input=room(width:w,height:h,withAvatar:false,withName:false,comment:"こんばんは\nまた来ます")
 let frame=try processor.process(input,orientation:.up)
 let selected=frame.messages ?? []
 let text=selected.map{$0.text}.joined().replacingOccurrences(of:" ",with:"")
 check("broad native missing avatar and name \(w)x\(h)",text.contains("こんばんは") && text.contains("また来ます"))
 check("broad native permits announcement",text.contains("公式アナウンス"))
 check("broad native excludes input control",!text.contains("メッセージ") && !text.contains("送信"))
 let detector=CommentDetector(filterSystemLabels:false,recallMode:true)
 check("broad native reaches speech candidates on first frame",detector.ingest(selected,now:0).count==selected.count && !selected.isEmpty)
 let cached=try processor.process(input,orientation:.up)
 check("broad native cache avoids OCR and duplicate speech",cached.recognitions==0 && detector.ingest(cached.messages ?? [],now:1).isEmpty)
 let keyboard=try processor.process(room(width:w,height:h,withAvatar:false,withName:false,keyboard:true),orientation:.up)
 let keyText=(keyboard.messages ?? []).map{$0.text}.joined().replacingOccurrences(of:" ",with:"")
 check("broad native keyboard excluded without losing comment",keyText.contains("こんばんは") && !keyText.contains("あ"))
}
for color in [CGColor(red:0.8,green:0.05,blue:0.6,alpha:1),CGColor(red:0.02,green:0.25,blue:0.7,alpha:1),CGColor(red:0.10,green:0.38,blue:0.48,alpha:1)] {
 let result=try ChatFrameProcessor(lightweight:false).process(room(width:1170,height:2532,withAvatar:false,withName:false,bubbleColor:color,whiteText:true),orientation:.up)
 check("broad native color independent without avatar",(result.messages ?? []).map{$0.text}.joined().contains("こんばんは"))
}
// Shipped lightweight balanced path. Earlier modes remain regression references.
for (w,h) in [(750,1334),(1170,2532),(1290,2796)] {
 let processor=ChatFrameProcessor()
 let input=room(width:w,height:h,withAvatar:false,withName:false,comment:"こんばんは\nまた来ます")
 let first=try processor.process(input,orientation:.up)
 let text=(first.messages ?? []).map{$0.text}.joined().replacingOccurrences(of:" ",with:"")
 check("balanced native body only without avatar \(w)x\(h)",first.messages?.count==1 && text=="こんばんはまた来ます")
 check("balanced cached frame skips OCR",try processor.process(input,orientation:.up).recognitions==0)
 let outside=try processor.process(room(width:w,height:h,withAvatar:true,withName:false,comment:"こんばんは\nまた来ます"),orientation:.up)
 check("outside avatar changes do not invalidate OCR",outside.recognitions==0)
 let keyboard=try processor.process(room(width:w,height:h,withAvatar:false,withName:false,keyboard:true),orientation:.up)
 check("balanced native keyboard excluded",keyboard.messages?.map{$0.text.replacingOccurrences(of:" ",with:"")}==["こんばんは"])
 let empty=try processor.process(room(width:w,height:h,withAvatar:false,withName:false,bubbleColor:CGColor(red:0.10,green:0.38,blue:0.48,alpha:1)),orientation:.up)
 check("no bubble surface skips OCR",empty.recognitions==0 && empty.messages?.isEmpty==true)
}
let threeBalanced=try ChatFrameProcessor().process(room(width:1170,height:2532,three:true),orientation:.up)
check("balanced preserves three message bodies",threeBalanced.messages?.map{$0.text.replacingOccurrences(of:" ",with:"")}==["こんばんは","ありがとう","よろしく"])
for color in [CGColor(gray:0.22,alpha:1),CGColor(red:0.8,green:0.05,blue:0.6,alpha:1),CGColor(red:0.02,green:0.25,blue:0.7,alpha:1)] {
 let result=try ChatFrameProcessor().process(room(width:1170,height:2532,withAvatar:false,withName:false,bubbleColor:color,whiteText:true),orientation:.up)
 check("balanced supports contrasting dark or colored bubble",result.messages?.first?.text.replacingOccurrences(of:" ",with:"")=="こんばんは")
}
var timings:[String:Double]=[:]
let benchmarkImage=room(width:750,height:1334,three:true)
for (name,processor) in [("v07_broad",ChatFrameProcessor(lightweight:false)),("v08_balanced",ChatFrameProcessor())] {
 _=try processor.process(benchmarkImage,orientation:.up)
 var samples:[Double]=[]
 for _ in 0..<5 {
  processor.reset();let start=ProcessInfo.processInfo.systemUptime
  _=try processor.process(benchmarkImage,orientation:.up)
  samples.append(ProcessInfo.processInfo.systemUptime-start)
 }
 timings[name]=samples.sorted()[samples.count/2]
}
print("::notice title=READER_BENCHMARK::"+String(data:try JSONSerialization.data(withJSONObject:timings,options:[.sortedKeys]),encoding:.utf8)!)
print("Native Vision tests: \(failures==0 ? "PASS":"FAIL") — generated test images, not a GRAVITY recording")
exit(failures==0 ? 0:1)
